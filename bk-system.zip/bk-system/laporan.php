<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$page_title = "Laporan & Statistik";
$page_subtitle = "Analisis data bimbingan konseling";

// Get statistics (filtered for konselor role)
if($_SESSION['role'] == 'konselor') {
    $stats = [
        'total_siswa' => $db->query("SELECT COUNT(*) as c FROM siswa")->fetch()['c'],
        'total_konseling' => $db->query("SELECT COUNT(*) as c FROM konseling WHERE konselor_id = " . $_SESSION['user_id'])->fetch()['c'],
        'total_pelanggaran' => $db->query("SELECT COUNT(*) as c FROM pelanggaran")->fetch()['c'],
        'total_prestasi' => $db->query("SELECT COUNT(*) as c FROM prestasi")->fetch()['c'],
        'konseling_bulan' => $db->query("SELECT COUNT(*) as c FROM konseling WHERE MONTH(tanggal_konseling)=MONTH(NOW()) AND konselor_id = " . $_SESSION['user_id'])->fetch()['c'],
        'pelanggaran_pending' => $db->query("SELECT COUNT(*) as c FROM pelanggaran WHERE status!='Selesai'")->fetch()['c']
    ];
} else {
    $stats = [
        'total_siswa' => $db->query("SELECT COUNT(*) as c FROM siswa")->fetch()['c'],
        'total_konseling' => $db->query("SELECT COUNT(*) as c FROM konseling")->fetch()['c'],
        'total_pelanggaran' => $db->query("SELECT COUNT(*) as c FROM pelanggaran")->fetch()['c'],
        'total_prestasi' => $db->query("SELECT COUNT(*) as c FROM prestasi")->fetch()['c'],
        'konseling_bulan' => $db->query("SELECT COUNT(*) as c FROM konseling WHERE MONTH(tanggal_konseling)=MONTH(NOW())")->fetch()['c'],
        'pelanggaran_pending' => $db->query("SELECT COUNT(*) as c FROM pelanggaran WHERE status!='Selesai'")->fetch()['c']
    ];
}

// Konseling by category (filtered for konselor role)
if($_SESSION['role'] == 'konselor') {
    $konseling_kategori = $db->query("SELECT kategori, COUNT(*) as jumlah FROM konseling WHERE konselor_id = " . $_SESSION['user_id'] . " GROUP BY kategori ORDER BY jumlah DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $konseling_kategori = $db->query("SELECT kategori, COUNT(*) as jumlah FROM konseling GROUP BY kategori ORDER BY jumlah DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
}

// Pelanggaran by tingkat
$pelanggaran_tingkat = $db->query("SELECT tingkat_pelanggaran, COUNT(*) as jumlah FROM pelanggaran GROUP BY tingkat_pelanggaran")->fetchAll(PDO::FETCH_ASSOC);

// Prestasi by tingkat
$prestasi_tingkat = $db->query("SELECT tingkat, COUNT(*) as jumlah FROM prestasi GROUP BY tingkat ORDER BY jumlah DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:24px;margin-bottom:30px}.stat-card{background:var(--white);padding:28px;border-radius:16px;box-shadow:0 2px 8px rgba(0,0,0,.05);position:relative;overflow:hidden;transition:all .3s}.stat-card:hover{transform:translateY(-5px);box-shadow:0 8px 24px rgba(0,0,0,.1)}.stat-icon{width:60px;height:60px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:26px;margin-bottom:20px}.stat-card.blue .stat-icon{background:rgba(52,152,219,.1);color:var(--info)}.stat-card.green .stat-icon{background:rgba(39,174,96,.1);color:var(--success)}.stat-card.orange .stat-icon{background:rgba(243,156,18,.1);color:var(--warning)}.stat-card.purple .stat-icon{background:rgba(155,89,182,.1);color:#9b59b6}.stat-card.red .stat-icon{background:rgba(231,76,60,.1);color:var(--danger)}.stat-card.gold .stat-icon{background:rgba(212,175,55,.1);color:var(--accent)}.stat-content h3{font-size:14px;color:var(--text-light);font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px}.stat-content .stat-number{font-size:36px;font-weight:700;color:var(--text);font-family:'Playfair Display',serif}.report-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:24px}.report-card{background:var(--white);border-radius:16px;padding:30px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.report-card h3{font-family:'Playfair Display',serif;font-size:20px;margin-bottom:20px;color:var(--text)}.report-item{display:flex;justify-content:space-between;align-items:center;padding:15px;background:var(--bg);border-radius:10px;margin-bottom:10px}.report-item:last-child{margin-bottom:0}.report-label{font-weight:600;color:var(--text)}.report-value{font-size:18px;font-weight:700;color:var(--primary);font-family:'Playfair Display',serif}.btn-export{padding:12px 24px;background:var(--success);color:var(--white);border:none;border-radius:12px;cursor:pointer;font-weight:600;transition:all .3s;display:inline-flex;align-items:center;gap:8px;text-decoration:none}.btn-export:hover{background:#229954;transform:translateY(-2px);box-shadow:0 4px 12px rgba(39,174,96,.3)}
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>
            
            <div style="margin-bottom:30px;display:flex;gap:10px;flex-wrap:wrap">
                <a href="export-data.php?type=siswa" class="btn-export">
                    <i class="fas fa-file-excel"></i> Export Data Siswa
                </a>
                <a href="export-data.php?type=konseling" class="btn-export">
                    <i class="fas fa-file-excel"></i> Export Konseling
                </a>
                <a href="export-data.php?type=pelanggaran" class="btn-export">
                    <i class="fas fa-file-excel"></i> Export Pelanggaran
                </a>
                <a href="export-data.php?type=prestasi" class="btn-export">
                    <i class="fas fa-file-excel"></i> Export Prestasi
                </a>
            </div>

            <div class="stats-grid">
                <div class="stat-card blue">
                    <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
                    <div class="stat-content">
                        <h3>Total Siswa</h3>
                        <div class="stat-number"><?php echo $stats['total_siswa']; ?></div>
                    </div>
                </div>
                <div class="stat-card green">
                    <div class="stat-icon"><i class="fas fa-comments"></i></div>
                    <div class="stat-content">
                        <h3>Total Konseling</h3>
                        <div class="stat-number"><?php echo $stats['total_konseling']; ?></div>
                    </div>
                </div>
                <div class="stat-card orange">
                    <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    <div class="stat-content">
                        <h3>Total Pelanggaran</h3>
                        <div class="stat-number"><?php echo $stats['total_pelanggaran']; ?></div>
                    </div>
                </div>
                <div class="stat-card gold">
                    <div class="stat-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stat-content">
                        <h3>Total Prestasi</h3>
                        <div class="stat-number"><?php echo $stats['total_prestasi']; ?></div>
                    </div>
                </div>
                <div class="stat-card purple">
                    <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
                    <div class="stat-content">
                        <h3>Konseling Bulan Ini</h3>
                        <div class="stat-number"><?php echo $stats['konseling_bulan']; ?></div>
                    </div>
                </div>
                <div class="stat-card red">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-content">
                        <h3>Pelanggaran Pending</h3>
                        <div class="stat-number"><?php echo $stats['pelanggaran_pending']; ?></div>
                    </div>
                </div>
            </div>

            <div class="report-grid">
                <div class="report-card">
                    <h3><i class="fas fa-tags"></i> Konseling per Kategori</h3>
                    <?php foreach($konseling_kategori as $k): ?>
                        <div class="report-item">
                            <span class="report-label"><?php echo htmlspecialchars($k['kategori']); ?></span>
                            <span class="report-value"><?php echo $k['jumlah']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="report-card">
                    <h3><i class="fas fa-layer-group"></i> Pelanggaran per Tingkat</h3>
                    <?php foreach($pelanggaran_tingkat as $p): ?>
                        <div class="report-item">
                            <span class="report-label"><?php echo $p['tingkat_pelanggaran']; ?></span>
                            <span class="report-value"><?php echo $p['jumlah']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="report-card">
                    <h3><i class="fas fa-medal"></i> Prestasi per Tingkat</h3>
                    <?php foreach($prestasi_tingkat as $p): ?>
                        <div class="report-item">
                            <span class="report-label"><?php echo $p['tingkat']; ?></span>
                            <span class="report-value"><?php echo $p['jumlah']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
