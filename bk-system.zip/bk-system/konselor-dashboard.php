<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get statistics for konselor
$query_siswa = "SELECT COUNT(*) as total FROM siswa";
$stmt_siswa = $db->query($query_siswa);
$total_siswa = $stmt_siswa->fetch(PDO::FETCH_ASSOC)['total'];

$query_konseling = "SELECT COUNT(*) as total FROM konseling WHERE MONTH(tanggal_konseling) = MONTH(CURRENT_DATE()) AND konselor_id = :konselor_id";
$stmt_konseling = $db->prepare($query_konseling);
$stmt_konseling->bindParam(':konselor_id', $_SESSION['user_id']);
$stmt_konseling->execute();
$konseling_bulan_ini = $stmt_konseling->fetch(PDO::FETCH_ASSOC)['total'];

$query_pelanggaran = "SELECT COUNT(*) as total FROM pelanggaran WHERE status != 'Selesai'";
$stmt_pelanggaran = $db->query($query_pelanggaran);
$pelanggaran_pending = $stmt_pelanggaran->fetch(PDO::FETCH_ASSOC)['total'];

$query_prestasi = "SELECT COUNT(*) as total FROM prestasi WHERE YEAR(tanggal_prestasi) = YEAR(CURRENT_DATE())";
$stmt_prestasi = $db->query($query_prestasi);
$prestasi_tahun_ini = $stmt_prestasi->fetch(PDO::FETCH_ASSOC)['total'];

// Recent counseling sessions for this konselor
$query_recent = "SELECT k.*, s.nama_lengkap, s.kelas, u.full_name as konselor
                 FROM konseling k
                 JOIN siswa s ON k.siswa_id = s.id
                 JOIN users u ON k.konselor_id = u.id
                 WHERE k.konselor_id = :konselor_id
                 ORDER BY k.tanggal_konseling DESC LIMIT 5";
$stmt_recent = $db->prepare($query_recent);
$stmt_recent->bindParam(':konselor_id', $_SESSION['user_id']);
$stmt_recent->execute();
$recent_konseling = $stmt_recent->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Konselor - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #1a472a;
            --primary-light: #2d5f3f;
            --accent: #d4af37;
            --text: #2c3e50;
            --text-light: #6c7a89;
            --bg: #f5f7fa;
            --white: #ffffff;
            --border: #e1e8ed;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
        }

        body {
            font-family: 'Source Sans Pro', sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-light) 100%);
            color: var(--white);
            padding: 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 12px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            font-size: 13px;
            opacity: 0.8;
        }

        .user-profile {
            padding: 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--accent);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: bold;
            color: var(--primary);
        }

        .user-info h3 {
            font-size: 16px;
            margin-bottom: 3px;
        }

        .user-info p {
            font-size: 12px;
            opacity: 0.7;
            text-transform: capitalize;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-item {
            margin: 5px 15px;
        }

        .nav-item a {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            gap: 15px;
        }

        .nav-item a:hover,
        .nav-item a.active {
            background: rgba(255, 255, 255, 0.15);
            color: var(--white);
        }

        .nav-item i {
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .top-bar {
            background: var(--white);
            padding: 20px 30px;
            border-radius: 16px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .page-title h1 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            color: var(--text);
            margin-bottom: 5px;
        }

        .page-title p {
            color: var(--text-light);
            font-size: 14px;
        }

        .logout-btn {
            padding: 12px 24px;
            background: var(--danger);
            color: var(--white);
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .logout-btn:hover {
            background: #c0392b;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(231, 76, 60, 0.3);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--white);
            padding: 28px;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            transform: translate(30%, -30%);
            opacity: 0.1;
        }

        .stat-card.blue::before { background: var(--info); }
        .stat-card.green::before { background: var(--success); }
        .stat-card.orange::before { background: var(--warning); }
        .stat-card.purple::before { background: #9b59b6; }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            margin-bottom: 20px;
        }

        .stat-card.blue .stat-icon { background: rgba(52, 152, 219, 0.1); color: var(--info); }
        .stat-card.green .stat-icon { background: rgba(39, 174, 96, 0.1); color: var(--success); }
        .stat-card.orange .stat-icon { background: rgba(243, 156, 18, 0.1); color: var(--warning); }
        .stat-card.purple .stat-icon { background: rgba(155, 89, 182, 0.1); color: #9b59b6; }

        .stat-content h3 {
            font-size: 14px;
            color: var(--text-light);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }

        .stat-content .stat-number {
            font-size: 36px;
            font-weight: 700;
            color: var(--text);
            font-family: 'Playfair Display', serif;
        }

        /* Recent Activity */
        .card {
            background: var(--white);
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border);
        }

        .card-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            color: var(--text);
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            padding: 20px;
            border-left: 3px solid var(--primary);
            margin-bottom: 15px;
            background: var(--bg);
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .activity-item:hover {
            background: #e8f4f8;
            border-left-color: var(--accent);
        }

        .activity-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }

        .activity-header h4 {
            color: var(--text);
            font-size: 16px;
        }

        .activity-date {
            color: var(--text-light);
            font-size: 13px;
        }

        .activity-info {
            color: var(--text-light);
            font-size: 14px;
            margin-bottom: 8px;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-terjadwal {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .status-selesai {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            .top-bar {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Sistem BK</h2>
                <p>Dashboard Konselor</p>
            </div>

            <div class="user-profile">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
                </div>
                <div class="user-info">
                    <h3><?php echo $_SESSION['full_name']; ?></h3>
                    <p><?php echo $_SESSION['role']; ?></p>
                </div>
            </div>

            <nav class="nav-menu">
                <div class="nav-item">
                    <a href="konselor-dashboard.php" class="active">
                        <i class="fas fa-th-large"></i>
                        <span>Dashboard</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="siswa.php">
                        <i class="fas fa-user-graduate"></i>
                        <span>Data Siswa</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="konseling.php">
                        <i class="fas fa-comments"></i>
                        <span>Konseling</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="pelanggaran.php">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Pelanggaran</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="prestasi.php">
                        <i class="fas fa-trophy"></i>
                        <span>Prestasi</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="kunjungan.php">
                        <i class="fas fa-clipboard-check"></i>
                        <span>Kunjungan</span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="laporan.php">
                        <i class="fas fa-chart-bar"></i>
                        <span>Laporan</span>
                    </a>
                </div>
            </nav>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <div class="page-title">
                    <h1>Dashboard Konselor</h1>
                    <p>Selamat datang di Sistem Bimbingan Konseling</p>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>

            <div class="stats-grid">
                <div class="stat-card blue">
                    <div class="stat-icon">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Total Siswa</h3>
                        <div class="stat-number"><?php echo $total_siswa; ?></div>
                    </div>
                </div>

                <div class="stat-card green">
                    <div class="stat-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Konseling Saya Bulan Ini</h3>
                        <div class="stat-number"><?php echo $konseling_bulan_ini; ?></div>
                    </div>
                </div>

                <div class="stat-card orange">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Pelanggaran Pending</h3>
                        <div class="stat-number"><?php echo $pelanggaran_pending; ?></div>
                    </div>
                </div>

                <div class="stat-card purple">
                    <div class="stat-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Prestasi Tahun Ini</h3>
                        <div class="stat-number"><?php echo $prestasi_tahun_ini; ?></div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>Sesi Konseling Saya Terbaru</h2>
                    <a href="konseling.php" style="color: var(--primary); text-decoration: none; font-weight: 600;">
                        Lihat Semua <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

                <ul class="activity-list">
                    <?php if(count($recent_konseling) > 0): ?>
                        <?php foreach($recent_konseling as $item): ?>
                            <li class="activity-item">
                                <div class="activity-header">
                                    <h4><?php echo htmlspecialchars($item['nama_lengkap']); ?></h4>
                                    <span class="activity-date">
                                        <i class="fas fa-calendar"></i>
                                        <?php echo date('d M Y', strtotime($item['tanggal_konseling'])); ?>
                                    </span>
                                </div>
                                <div class="activity-info">
                                    <i class="fas fa-user"></i> Kelas: <?php echo htmlspecialchars($item['kelas']); ?> |
                                    <i class="fas fa-tag"></i> <?php echo htmlspecialchars($item['kategori']); ?> |
                                    <i class="fas fa-user-tie"></i> Konselor: <?php echo htmlspecialchars($item['konselor']); ?>
                                </div>
                                <span class="status-badge status-<?php echo strtolower($item['status']); ?>">
                                    <?php echo $item['status']; ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li class="activity-item">
                            <p style="text-align: center; color: var(--text-light);">Belum ada data konseling</p>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </main>
    </div>
</body>
</html>
