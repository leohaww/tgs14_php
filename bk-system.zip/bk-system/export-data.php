<?php
session_start();
if(!isset($_SESSION['user_id'])) { 
    header("Location: index.php"); 
    exit(); 
}

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

if(!isset($_GET['type'])) {
    header("Location: laporan.php");
    exit();
}

$type = $_GET['type'];
$filename = $type . '_' . date('Y-m-d_His') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');

// Add BOM for Excel UTF-8 support
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

switch($type) {
    case 'siswa':
        fputcsv($output, ['NIS', 'Nama Lengkap', 'Jenis Kelamin', 'Kelas', 'Tahun Ajaran', 'Tanggal Lahir', 'Alamat', 'No. Telp', 'Email', 'Nama Wali', 'No. Telp Wali']);
        $query = "SELECT nis, nama_lengkap, jenis_kelamin, kelas, tahun_ajaran, tanggal_lahir, alamat, no_telp, email, nama_wali, no_telp_wali FROM siswa ORDER BY nama_lengkap";
        $stmt = $db->query($query);
        while($row = $stmt->fetch(PDO::FETCH_NUM)) {
            fputcsv($output, $row);
        }
        break;
        
    case 'konseling':
        fputcsv($output, ['Tanggal', 'NIS', 'Nama Siswa', 'Kelas', 'Jenis Konseling', 'Kategori', 'Permasalahan', 'Solusi', 'Status', 'Konselor']);
        $query = "SELECT k.tanggal_konseling, s.nis, s.nama_lengkap, s.kelas, k.jenis_konseling, k.kategori, k.permasalahan, k.solusi, k.status, u.full_name 
                  FROM konseling k 
                  JOIN siswa s ON k.siswa_id = s.id 
                  JOIN users u ON k.konselor_id = u.id 
                  ORDER BY k.tanggal_konseling DESC";
        $stmt = $db->query($query);
        while($row = $stmt->fetch(PDO::FETCH_NUM)) {
            fputcsv($output, $row);
        }
        break;
        
    case 'pelanggaran':
        fputcsv($output, ['Tanggal', 'NIS', 'Nama Siswa', 'Kelas', 'Jenis Pelanggaran', 'Tingkat', 'Deskripsi', 'Sanksi', 'Poin', 'Status']);
        $query = "SELECT p.tanggal_pelanggaran, s.nis, s.nama_lengkap, s.kelas, p.jenis_pelanggaran, p.tingkat_pelanggaran, p.deskripsi, p.sanksi, p.poin, p.status 
                  FROM pelanggaran p 
                  JOIN siswa s ON p.siswa_id = s.id 
                  ORDER BY p.tanggal_pelanggaran DESC";
        $stmt = $db->query($query);
        while($row = $stmt->fetch(PDO::FETCH_NUM)) {
            fputcsv($output, $row);
        }
        break;
        
    case 'prestasi':
        fputcsv($output, ['Tanggal', 'NIS', 'Nama Siswa', 'Kelas', 'Jenis Prestasi', 'Tingkat', 'Peringkat', 'Penyelenggara', 'Deskripsi']);
        $query = "SELECT p.tanggal_prestasi, s.nis, s.nama_lengkap, s.kelas, p.jenis_prestasi, p.tingkat, p.peringkat, p.penyelenggara, p.deskripsi 
                  FROM prestasi p 
                  JOIN siswa s ON p.siswa_id = s.id 
                  ORDER BY p.tanggal_prestasi DESC";
        $stmt = $db->query($query);
        while($row = $stmt->fetch(PDO::FETCH_NUM)) {
            fputcsv($output, $row);
        }
        break;
        
    default:
        header("Location: laporan.php");
        exit();
}

fclose($output);
exit();
?>
