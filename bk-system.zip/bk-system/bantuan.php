<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
$page_title = "Bantuan & Panduan";
$page_subtitle = "Panduan penggunaan sistem BK";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .help-grid{display:grid;grid-template-columns:250px 1fr;gap:30px}.help-nav{background:var(--white);border-radius:16px;padding:25px;box-shadow:0 2px 8px rgba(0,0,0,.05);height:fit-content;position:sticky;top:30px}.help-nav h3{font-family:'Playfair Display',serif;font-size:18px;margin-bottom:20px;color:var(--text)}.help-nav ul{list-style:none}.help-nav li{margin-bottom:10px}.help-nav a{display:block;padding:10px 15px;color:var(--text);text-decoration:none;border-radius:8px;transition:all .3s}.help-nav a:hover,.help-nav a.active{background:var(--primary);color:var(--white)}.help-content{background:var(--white);border-radius:16px;padding:40px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.help-section{margin-bottom:50px;scroll-margin-top:100px}.help-section h2{font-family:'Playfair Display',serif;font-size:28px;color:var(--text);margin-bottom:20px;padding-bottom:15px;border-bottom:2px solid var(--border)}.help-section h3{font-size:20px;color:var(--primary);margin:25px 0 15px}.help-section p{line-height:1.8;color:var(--text-light);margin-bottom:15px}.help-section ol,.help-section ul{margin:15px 0;padding-left:25px}.help-section li{margin-bottom:10px;line-height:1.6}.code-box{background:var(--bg);border-left:4px solid var(--primary);padding:15px 20px;border-radius:8px;margin:15px 0;font-family:monospace;font-size:14px}.tip-box{background:rgba(39,174,96,.1);border-left:4px solid var(--success);padding:15px 20px;border-radius:8px;margin:15px 0}.tip-box strong{color:var(--success)}.warning-box{background:rgba(243,156,18,.1);border-left:4px solid var(--warning);padding:15px 20px;border-radius:8px;margin:15px 0}.warning-box strong{color:var(--warning)}@media(max-width:768px){.help-grid{grid-template-columns:1fr}.help-nav{position:static}}
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>

            <div class="help-grid">
                <div class="help-nav">
                    <h3>Daftar Isi</h3>
                    <ul>
                        <li><a href="#pengenalan" class="active">Pengenalan</a></li>
                        <li><a href="#login">Login</a></li>
                        <li><a href="#dashboard">Dashboard</a></li>
                        <li><a href="#siswa">Data Siswa</a></li>
                        <li><a href="#konseling">Konseling</a></li>
                        <li><a href="#pelanggaran">Pelanggaran</a></li>
                        <li><a href="#prestasi">Prestasi</a></li>
                        <li><a href="#laporan">Laporan</a></li>
                        <li><a href="#profil">Profil</a></li>
                        <li><a href="#tips">Tips & Trik</a></li>
                    </ul>
                </div>

                <div class="help-content">
                    <div id="pengenalan" class="help-section">
                        <h2><i class="fas fa-info-circle"></i> Pengenalan Sistem</h2>
                        <p>Sistem Administrasi Bimbingan Konseling adalah aplikasi berbasis web yang dirancang untuk membantu guru BK dalam mengelola data dan aktivitas bimbingan konseling di sekolah.</p>
                        
                        <h3>Fitur Utama</h3>
                        <ul>
                            <li><strong>Manajemen Data Siswa</strong> - Kelola data siswa secara lengkap</li>
                            <li><strong>Pencatatan Konseling</strong> - Catat sesi konseling dengan detail</li>
                            <li><strong>Tracking Pelanggaran</strong> - Monitor pelanggaran dan poin siswa</li>
                            <li><strong>Pencatatan Prestasi</strong> - Dokumentasi prestasi siswa</li>
                            <li><strong>Laporan & Statistik</strong> - Analisis data BK</li>
                            <li><strong>Export Data</strong> - Export ke format CSV/Excel</li>
                        </ul>
                    </div>

                    <div id="login" class="help-section">
                        <h2><i class="fas fa-sign-in-alt"></i> Login ke Sistem</h2>
                        
                        <h3>Cara Login</h3>
                        <ol>
                            <li>Buka aplikasi di browser (http://localhost/bk-system)</li>
                            <li>Masukkan username dan password Anda</li>
                            <li>Klik tombol "Masuk"</li>
                        </ol>

                        <div class="tip-box">
                            <strong>💡 Tips:</strong> Gunakan akun demo untuk percobaan pertama:
                            <ul style="margin-top:10px">
                                <li>Admin: username <code>admin</code>, password <code>password</code></li>
                                <li>User: username <code>konselor</code>, password <code>password</code></li>
                            </ul>
                        </div>

                        <div class="warning-box">
                            <strong>⚠️ Penting:</strong> Segera ubah password default setelah login pertama kali di menu Profil Saya.
                        </div>
                    </div>

                    <div id="dashboard" class="help-section">
                        <h2><i class="fas fa-th-large"></i> Dashboard</h2>
                        <p>Dashboard menampilkan ringkasan statistik dan aktivitas terbaru sistem BK.</p>
                        
                        <h3>Komponen Dashboard</h3>
                        <ul>
                            <li><strong>Kartu Statistik</strong> - Menampilkan total siswa, konseling, pelanggaran, dan prestasi</li>
                            <li><strong>Aktivitas Terbaru</strong> - 5 sesi konseling terakhir</li>
                            <li><strong>Quick Actions</strong> - Akses cepat ke fitur utama</li>
                        </ul>
                    </div>

                    <div id="siswa" class="help-section">
                        <h2><i class="fas fa-user-graduate"></i> Manajemen Data Siswa</h2>
                        
                        <h3>Menambah Data Siswa</h3>
                        <ol>
                            <li>Klik menu "Data Siswa" di sidebar</li>
                            <li>Klik tombol "Tambah Siswa"</li>
                            <li>Isi form dengan data lengkap siswa:
                                <ul>
                                    <li>NIS (wajib, unique)</li>
                                    <li>Nama lengkap (wajib)</li>
                                    <li>Jenis kelamin (wajib)</li>
                                    <li>Kelas dan tahun ajaran (wajib)</li>
                                    <li>Data tambahan (opsional)</li>
                                </ul>
                            </li>
                            <li>Klik "Simpan"</li>
                        </ol>

                        <h3>Mengedit Data Siswa</h3>
                        <ol>
                            <li>Cari siswa yang ingin diedit</li>
                            <li>Klik tombol "Edit"</li>
                            <li>Ubah data yang diperlukan</li>
                            <li>Klik "Simpan"</li>
                        </ol>

                        <h3>Melihat Detail Siswa</h3>
                        <ol>
                            <li>Klik tombol "Detail" pada data siswa</li>
                            <li>Anda akan melihat:
                                <ul>
                                    <li>Data pribadi lengkap</li>
                                    <li>Statistik (konseling, pelanggaran, prestasi)</li>
                                    <li>Riwayat konseling</li>
                                    <li>Daftar pelanggaran</li>
                                    <li>Daftar prestasi</li>
                                </ul>
                            </li>
                        </ol>

                        <div class="tip-box">
                            <strong>💡 Tips:</strong> Gunakan fitur search untuk mencari siswa berdasarkan nama atau NIS dengan cepat.
                        </div>
                    </div>

                    <div id="konseling" class="help-section">
                        <h2><i class="fas fa-comments"></i> Manajemen Konseling</h2>
                        
                        <h3>Menambah Sesi Konseling</h3>
                        <ol>
                            <li>Klik menu "Konseling"</li>
                            <li>Klik "Tambah Konseling"</li>
                            <li>Pilih siswa dari dropdown</li>
                            <li>Isi tanggal dan waktu konseling</li>
                            <li>Pilih jenis konseling (Individual/Kelompok/Klasikal)</li>
                            <li>Pilih kategori (Akademik/Pribadi/Sosial/Karir)</li>
                            <li>Tulis permasalahan (wajib)</li>
                            <li>Isi solusi dan tindak lanjut</li>
                            <li>Pilih status</li>
                            <li>Klik "Simpan"</li>
                        </ol>

                        <h3>Kategori Konseling</h3>
                        <ul>
                            <li><strong>Akademik</strong> - Masalah pembelajaran, prestasi belajar, kesulitan mata pelajaran</li>
                            <li><strong>Pribadi</strong> - Masalah emosi, kepercayaan diri, motivasi</li>
                            <li><strong>Sosial</strong> - Hubungan dengan teman, adaptasi, konflik</li>
                            <li><strong>Karir</strong> - Pilihan jurusan, rencana karir, minat bakat</li>
                        </ul>
                    </div>

                    <div id="pelanggaran" class="help-section">
                        <h2><i class="fas fa-exclamation-triangle"></i> Manajemen Pelanggaran</h2>
                        
                        <h3>Mencatat Pelanggaran</h3>
                        <ol>
                            <li>Klik menu "Pelanggaran"</li>
                            <li>Klik "Tambah Pelanggaran"</li>
                            <li>Pilih siswa</li>
                            <li>Isi tanggal pelanggaran</li>
                            <li>Tulis jenis pelanggaran</li>
                            <li>Pilih tingkat (Ringan/Sedang/Berat)</li>
                            <li>Isi deskripsi dan sanksi</li>
                            <li>Masukkan poin pelanggaran</li>
                            <li>Klik "Simpan"</li>
                        </ol>

                        <h3>Tingkat Pelanggaran</h3>
                        <ul>
                            <li><strong>Ringan</strong> - Terlambat, seragam tidak lengkap, dll (Poin: 5-10)</li>
                            <li><strong>Sedang</strong> - Tidak masuk tanpa keterangan, keluar kelas, dll (Poin: 15-25)</li>
                            <li><strong>Berat</strong> - Merokok, berkelahi, menyontek ujian, dll (Poin: 30-50)</li>
                        </ul>
                    </div>

                    <div id="prestasi" class="help-section">
                        <h2><i class="fas fa-trophy"></i> Manajemen Prestasi</h2>
                        
                        <h3>Mencatat Prestasi</h3>
                        <ol>
                            <li>Klik menu "Prestasi"</li>
                            <li>Klik "Tambah Prestasi"</li>
                            <li>Pilih siswa</li>
                            <li>Isi tanggal prestasi</li>
                            <li>Tulis jenis prestasi (contoh: Olimpiade Matematika)</li>
                            <li>Pilih tingkat (Sekolah s/d Internasional)</li>
                            <li>Isi peringkat (contoh: Juara 1, Medali Emas)</li>
                            <li>Isi penyelenggara</li>
                            <li>Klik "Simpan"</li>
                        </ol>
                    </div>

                    <div id="laporan" class="help-section">
                        <h2><i class="fas fa-chart-bar"></i> Laporan & Statistik</h2>
                        
                        <h3>Melihat Laporan</h3>
                        <p>Halaman laporan menampilkan statistik lengkap dan dapat diexport:</p>
                        <ul>
                            <li>Total keseluruhan data</li>
                            <li>Konseling per kategori</li>
                            <li>Pelanggaran per tingkat</li>
                            <li>Prestasi per tingkat</li>
                        </ul>

                        <h3>Export Data</h3>
                        <ol>
                            <li>Buka halaman "Laporan"</li>
                            <li>Klik tombol export sesuai data yang diinginkan</li>
                            <li>File CSV akan otomatis terdownload</li>
                            <li>Buka file dengan Excel atau Google Sheets</li>
                        </ol>

                        <div class="tip-box">
                            <strong>💡 Tips:</strong> Export data secara berkala untuk backup dan analisis lebih lanjut.
                        </div>
                    </div>

                    <div id="profil" class="help-section">
                        <h2><i class="fas fa-user-circle"></i> Mengelola Profil</h2>
                        
                        <h3>Mengubah Profil</h3>
                        <ol>
                            <li>Klik menu "Profil Saya"</li>
                            <li>Edit nama lengkap atau email</li>
                            <li>Klik "Simpan Perubahan"</li>
                        </ol>

                        <h3>Mengubah Password</h3>
                        <ol>
                            <li>Klik menu "Profil Saya"</li>
                            <li>Scroll ke bagian "Ubah Password"</li>
                            <li>Masukkan password saat ini</li>
                            <li>Masukkan password baru (minimal 6 karakter)</li>
                            <li>Konfirmasi password baru</li>
                            <li>Klik "Ubah Password"</li>
                        </ol>

                        <div class="warning-box">
                            <strong>⚠️ Keamanan:</strong> Gunakan password yang kuat dengan kombinasi huruf, angka, dan simbol.
                        </div>
                    </div>

                    <div id="tips" class="help-section">
                        <h2><i class="fas fa-lightbulb"></i> Tips & Trik</h2>
                        
                        <h3>Best Practices</h3>
                        <ul>
                            <li>📝 <strong>Catat Segera</strong> - Input data konseling sesegera mungkin setelah sesi</li>
                            <li>🔍 <strong>Gunakan Search</strong> - Manfaatkan fitur pencarian untuk efisiensi</li>
                            <li>💾 <strong>Backup Rutin</strong> - Export data secara berkala</li>
                            <li>🔒 <strong>Logout Selalu</strong> - Jangan lupa logout setelah selesai</li>
                            <li>📊 <strong>Review Berkala</strong> - Cek laporan untuk evaluasi</li>
                            <li>✏️ <strong>Detail Lengkap</strong> - Isi data selengkap mungkin</li>
                        </ul>

                        <h3>Keyboard Shortcuts</h3>
                        <div class="code-box">
                            Ctrl + F - Search dalam halaman<br>
                            Ctrl + P - Print halaman detail siswa<br>
                            Tab - Navigate antar form field<br>
                            Enter - Submit form
                        </div>

                        <h3>Troubleshooting</h3>
                        <ul>
                            <li><strong>Lupa Password?</strong> - Hubungi administrator untuk reset</li>
                            <li><strong>Data tidak tersimpan?</strong> - Cek koneksi internet dan isi field required</li>
                            <li><strong>Halaman lambat?</strong> - Clear browser cache</li>
                            <li><strong>Error saat export?</strong> - Pastikan ada data yang akan diexport</li>
                        </ul>
                    </div>

                    <div style="background:var(--bg);padding:30px;border-radius:12px;text-align:center;margin-top:50px">
                        <h3 style="margin-bottom:15px">Butuh Bantuan Lebih Lanjut?</h3>
                        <p>Hubungi administrator sistem atau baca dokumentasi lengkap di README.md</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Smooth scroll untuk navigasi
        document.querySelectorAll('.help-nav a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                
                // Update active state
                document.querySelectorAll('.help-nav a').forEach(a => a.classList.remove('active'));
                this.classList.add('active');
            });
        });

        // Highlight active section on scroll
        window.addEventListener('scroll', () => {
            const sections = document.querySelectorAll('.help-section');
            const navLinks = document.querySelectorAll('.help-nav a');
            
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                if (window.pageYOffset >= sectionTop - 150) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === '#' + current) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>
