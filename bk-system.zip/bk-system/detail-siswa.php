<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
require_once 'config/database.php';

if(!isset($_GET['id'])) { header("Location: siswa.php"); exit(); }

$database = new Database();
$db = $database->getConnection();
$siswa_id = $_GET['id'];

// Get student data
$query = "SELECT * FROM siswa WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $siswa_id);
$stmt->execute();
$siswa = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$siswa) { header("Location: siswa.php"); exit(); }

$page_title = "Detail Siswa - " . $siswa['nama_lengkap'];
$page_subtitle = "Informasi lengkap siswa";

// Get konseling history
$konseling = $db->prepare("SELECT k.*, u.full_name as konselor FROM konseling k JOIN users u ON k.konselor_id = u.id WHERE siswa_id = :id ORDER BY tanggal_konseling DESC LIMIT 5");
$konseling->execute([':id' => $siswa_id]);
$riwayat_konseling = $konseling->fetchAll(PDO::FETCH_ASSOC);

// Get pelanggaran
$pelanggaran = $db->prepare("SELECT * FROM pelanggaran WHERE siswa_id = :id ORDER BY tanggal_pelanggaran DESC LIMIT 5");
$pelanggaran->execute([':id' => $siswa_id]);
$riwayat_pelanggaran = $pelanggaran->fetchAll(PDO::FETCH_ASSOC);

// Get prestasi
$prestasi = $db->prepare("SELECT * FROM prestasi WHERE siswa_id = :id ORDER BY tanggal_prestasi DESC");
$prestasi->execute([':id' => $siswa_id]);
$riwayat_prestasi = $prestasi->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$total_konseling = $db->prepare("SELECT COUNT(*) as c FROM konseling WHERE siswa_id = :id");
$total_konseling->execute([':id' => $siswa_id]);
$stat_konseling = $total_konseling->fetch()['c'];

$total_pelanggaran = $db->prepare("SELECT COUNT(*) as c, SUM(poin) as total_poin FROM pelanggaran WHERE siswa_id = :id");
$total_pelanggaran->execute([':id' => $siswa_id]);
$stat_pel = $total_pelanggaran->fetch();

$total_prestasi = $db->prepare("SELECT COUNT(*) as c FROM prestasi WHERE siswa_id = :id");
$total_prestasi->execute([':id' => $siswa_id]);
$stat_prestasi = $total_prestasi->fetch()['c'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .back-btn{padding:10px 20px;background:var(--border);color:var(--text);border:none;border-radius:10px;text-decoration:none;display:inline-flex;align-items:center;gap:8px;margin-bottom:20px;transition:all .3s}.back-btn:hover{background:var(--text-light);color:var(--white)}.student-header{background:linear-gradient(135deg,var(--primary),var(--primary-light));color:var(--white);padding:40px;border-radius:16px;margin-bottom:30px;box-shadow:0 4px 16px rgba(26,71,42,.3)}.student-header-content{display:flex;align-items:center;gap:30px}.student-avatar{width:100px;height:100px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;font-size:42px;font-weight:bold;color:var(--primary);box-shadow:0 4px 12px rgba(0,0,0,.2)}.student-info h1{font-family:'Playfair Display',serif;font-size:36px;margin-bottom:10px}.student-meta{display:flex;gap:25px;font-size:15px;opacity:.9}.student-meta div{display:flex;align-items:center;gap:8px}.stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:30px}.stat-box{background:var(--white);padding:25px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center}.stat-box-icon{width:50px;height:50px;margin:0 auto 15px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:24px}.stat-box.blue .stat-box-icon{background:rgba(52,152,219,.1);color:var(--info)}.stat-box.orange .stat-box-icon{background:rgba(243,156,18,.1);color:var(--warning)}.stat-box.gold .stat-box-icon{background:rgba(212,175,55,.1);color:var(--accent)}.stat-box-number{font-size:28px;font-weight:700;color:var(--text);font-family:'Playfair Display',serif;margin-bottom:5px}.stat-box-label{font-size:13px;color:var(--text-light);text-transform:uppercase}.detail-grid{display:grid;grid-template-columns:1fr 2fr;gap:30px;margin-bottom:30px}.info-card{background:var(--white);padding:30px;border-radius:16px;box-shadow:0 2px 8px rgba(0,0,0,.05)}.info-card h3{font-family:'Playfair Display',serif;font-size:20px;margin-bottom:20px;padding-bottom:15px;border-bottom:2px solid var(--border)}.info-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border)}.info-row:last-child{border-bottom:none}.info-label{color:var(--text-light);font-weight:600}.info-value{color:var(--text);font-weight:600;text-align:right}.section-tabs{display:flex;gap:10px;margin-bottom:20px;border-bottom:2px solid var(--border)}.tab-btn{padding:12px 24px;background:none;border:none;border-bottom:3px solid transparent;cursor:pointer;font-weight:600;color:var(--text-light);transition:all .3s}.tab-btn.active{color:var(--primary);border-bottom-color:var(--primary)}.tab-content{display:none}.tab-content.active{display:block}.timeline{position:relative;padding-left:30px}.timeline::before{content:'';position:absolute;left:0;top:0;bottom:0;width:2px;background:var(--border)}.timeline-item{position:relative;margin-bottom:25px;padding-bottom:25px;border-bottom:1px solid var(--border)}.timeline-item::before{content:'';position:absolute;left:-34px;width:10px;height:10px;border-radius:50%;background:var(--primary)}.timeline-item:last-child{border-bottom:none}.timeline-date{color:var(--text-light);font-size:13px;margin-bottom:8px}.timeline-title{font-weight:600;color:var(--text);margin-bottom:5px}.timeline-desc{color:var(--text-light);font-size:14px;line-height:1.6}.badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;margin-left:10px}.print-btn{padding:10px 20px;background:var(--success);color:var(--white);border:none;border-radius:10px;cursor:pointer;display:inline-flex;align-items:center;gap:8px;transition:all .3s}.print-btn:hover{background:#229954;transform:translateY(-2px)}@media(max-width:768px){.detail-grid{grid-template-columns:1fr}.student-header-content{flex-direction:column;text-align:center}}
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>

            <a href="siswa.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Kembali ke Daftar Siswa
            </a>

            <div class="student-header">
                <div class="student-header-content">
                    <div class="student-avatar">
                        <?php echo strtoupper(substr($siswa['nama_lengkap'], 0, 1)); ?>
                    </div>
                    <div class="student-info">
                        <h1><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></h1>
                        <div class="student-meta">
                            <div><i class="fas fa-id-card"></i> NIS: <?php echo $siswa['nis']; ?></div>
                            <div><i class="fas fa-school"></i> Kelas: <?php echo $siswa['kelas']; ?></div>
                            <div><i class="fas fa-calendar"></i> <?php echo $siswa['tahun_ajaran']; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="stats-row">
                <div class="stat-box blue">
                    <div class="stat-box-icon"><i class="fas fa-comments"></i></div>
                    <div class="stat-box-number"><?php echo $stat_konseling; ?></div>
                    <div class="stat-box-label">Sesi Konseling</div>
                </div>
                <div class="stat-box orange">
                    <div class="stat-box-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    <div class="stat-box-number"><?php echo $stat_pel['c'] ?? 0; ?></div>
                    <div class="stat-box-label">Pelanggaran</div>
                    <small style="color:var(--text-light)">Poin: <?php echo $stat_pel['total_poin'] ?? 0; ?></small>
                </div>
                <div class="stat-box gold">
                    <div class="stat-box-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stat-box-number"><?php echo $stat_prestasi; ?></div>
                    <div class="stat-box-label">Prestasi</div>
                </div>
            </div>

            <div class="detail-grid">
                <div class="info-card">
                    <h3><i class="fas fa-user"></i> Data Pribadi</h3>
                    <div class="info-row">
                        <span class="info-label">Nama Lengkap:</span>
                        <span class="info-value"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">NIS:</span>
                        <span class="info-value"><?php echo $siswa['nis']; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Jenis Kelamin:</span>
                        <span class="info-value"><?php echo $siswa['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Tanggal Lahir:</span>
                        <span class="info-value"><?php echo $siswa['tanggal_lahir'] ? date('d M Y', strtotime($siswa['tanggal_lahir'])) : '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Alamat:</span>
                        <span class="info-value"><?php echo htmlspecialchars($siswa['alamat'] ?? '-'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">No. Telepon:</span>
                        <span class="info-value"><?php echo htmlspecialchars($siswa['no_telp'] ?? '-'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($siswa['email'] ?? '-'); ?></span>
                    </div>

                    <h3 style="margin-top:30px"><i class="fas fa-users"></i> Data Wali</h3>
                    <div class="info-row">
                        <span class="info-label">Nama Wali:</span>
                        <span class="info-value"><?php echo htmlspecialchars($siswa['nama_wali'] ?? '-'); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">No. Telp Wali:</span>
                        <span class="info-value"><?php echo htmlspecialchars($siswa['no_telp_wali'] ?? '-'); ?></span>
                    </div>

                    <button class="print-btn" onclick="window.print()" style="margin-top:20px;width:100%">
                        <i class="fas fa-print"></i> Cetak Data Siswa
                    </button>
                </div>

                <div class="info-card">
                    <div class="section-tabs">
                        <button class="tab-btn active" onclick="switchTab('konseling')">Riwayat Konseling</button>
                        <button class="tab-btn" onclick="switchTab('pelanggaran')">Pelanggaran</button>
                        <button class="tab-btn" onclick="switchTab('prestasi')">Prestasi</button>
                    </div>

                    <div id="tab-konseling" class="tab-content active">
                        <div class="timeline">
                            <?php if(count($riwayat_konseling) > 0): ?>
                                <?php foreach($riwayat_konseling as $k): ?>
                                    <div class="timeline-item">
                                        <div class="timeline-date"><?php echo date('d M Y H:i', strtotime($k['tanggal_konseling'])); ?></div>
                                        <div class="timeline-title">
                                            <?php echo htmlspecialchars($k['kategori']); ?>
                                            <span class="badge" style="background:rgba(52,152,219,.1);color:var(--info)"><?php echo $k['jenis_konseling']; ?></span>
                                            <span class="badge status-<?php echo strtolower($k['status']); ?>"><?php echo $k['status']; ?></span>
                                        </div>
                                        <div class="timeline-desc">
                                            <strong>Permasalahan:</strong> <?php echo htmlspecialchars(substr($k['permasalahan'], 0, 150)); ?>...<br>
                                            <small><i class="fas fa-user-tie"></i> Konselor: <?php echo htmlspecialchars($k['konselor']); ?></small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="text-align:center;color:var(--text-light);padding:40px">Belum ada riwayat konseling</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="tab-pelanggaran" class="tab-content">
                        <div class="timeline">
                            <?php if(count($riwayat_pelanggaran) > 0): ?>
                                <?php foreach($riwayat_pelanggaran as $p): ?>
                                    <div class="timeline-item">
                                        <div class="timeline-date"><?php echo date('d M Y', strtotime($p['tanggal_pelanggaran'])); ?></div>
                                        <div class="timeline-title">
                                            <?php echo htmlspecialchars($p['jenis_pelanggaran']); ?>
                                            <span class="badge badge-<?php echo strtolower($p['tingkat_pelanggaran']); ?>"><?php echo $p['tingkat_pelanggaran']; ?></span>
                                        </div>
                                        <div class="timeline-desc">
                                            <?php echo htmlspecialchars($p['deskripsi']); ?><br>
                                            <small><strong>Poin:</strong> <?php echo $p['poin']; ?> | <strong>Sanksi:</strong> <?php echo htmlspecialchars($p['sanksi'] ?? '-'); ?></small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="text-align:center;color:var(--text-light);padding:40px">Tidak ada catatan pelanggaran</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="tab-prestasi" class="tab-content">
                        <div class="timeline">
                            <?php if(count($riwayat_prestasi) > 0): ?>
                                <?php foreach($riwayat_prestasi as $p): ?>
                                    <div class="timeline-item">
                                        <div class="timeline-date"><?php echo date('d M Y', strtotime($p['tanggal_prestasi'])); ?></div>
                                        <div class="timeline-title">
                                            <i class="fas fa-trophy" style="color:var(--accent)"></i>
                                            <?php echo htmlspecialchars($p['jenis_prestasi']); ?>
                                            <span class="badge badge-<?php echo strtolower($p['tingkat']); ?>"><?php echo $p['tingkat']; ?></span>
                                        </div>
                                        <div class="timeline-desc">
                                            <strong>Peringkat:</strong> <?php echo htmlspecialchars($p['peringkat']); ?><br>
                                            <strong>Penyelenggara:</strong> <?php echo htmlspecialchars($p['penyelenggara']); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p style="text-align:center;color:var(--text-light);padding:40px">Belum ada prestasi tercatat</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        function switchTab(tab){
            document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c=>c.classList.remove('active'));
            event.target.classList.add('active');
            document.getElementById('tab-'+tab).classList.add('active');
        }
    </script>
</body>
</html>
