<?php
// Test script to verify role-based redirect logic
session_start();

// Simulate different user roles
$test_roles = ['admin', 'konselor', 'user'];

foreach ($test_roles as $role) {
    $_SESSION['role'] = $role;
    $_SESSION['user_id'] = 1;

    // Test login redirect logic
    if(isset($_SESSION['user_id'])) {
        if($_SESSION['role'] == 'admin') {
            $redirect = "dashboard.php";
        } elseif($_SESSION['role'] == 'konselor') {
            $redirect = "konselor-dashboard.php";
        } else {
            $redirect = "user-dashboard.php";
        }
        echo "Role: $role -> Redirect to: $redirect\n";
    }

    // Test sidebar dashboard link
    $dashboard_link = 'dashboard.php';
    if($_SESSION['role'] == 'konselor') {
        $dashboard_link = 'konselor-dashboard.php';
    } elseif($_SESSION['role'] == 'user') {
        $dashboard_link = 'user-dashboard.php';
    }
    echo "Role: $role -> Dashboard link: $dashboard_link\n";

    echo "---\n";
}

echo "Role-based redirect logic test completed.\n";
?>
