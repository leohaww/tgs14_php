# Sistem Administrasi Bimbingan Konseling

Sistem informasi berbasis web untuk mengelola administrasi bimbingan konseling sekolah dengan tampilan modern, elegan, dan responsive.

## Fitur Utama

### 🎯 Manajemen Data Siswa
- CRUD (Create, Read, Update, Delete) data siswa lengkap
- Pencarian dan filter siswa
- Data pribadi, akademik, dan kontak wali

### 💬 Manajemen Konseling
- Pencatatan sesi konseling individual, kelompok, dan klasikal
- Kategorisasi konseling (Akademik, Pribadi, Sosial, Karir)
- Tracking permasalahan, solusi, dan tindak lanjut
- Status konseling (Terjadwal, Selesai, Dibatalkan)

### ⚠️ Manajemen Pelanggaran
- Pencatatan pelanggaran siswa dengan tingkat (Ringan, Sedang, Berat)
- Sistem poin pelanggaran
- Tracking sanksi dan status penyelesaian

### 🏆 Manajemen Prestasi
- Pencatatan prestasi siswa berbagai tingkat
- Tingkat: Sekolah, Kecamatan, Kabupaten, Provinsi, Nasional, Internasional
- Detail peringkat dan penyelenggara

### 📋 Kunjungan Siswa
- Pencatatan kunjungan siswa ke ruang BK
- Tujuan dan hasil kunjungan
- Tracking petugas yang melayani

### 👥 Manajemen User (Admin)
- Role-based access (Admin & User)
- Tambah, edit user
- Keamanan dengan enkripsi password

### 📊 Laporan & Statistik
- Dashboard statistik real-time
- Laporan konseling per kategori
- Laporan pelanggaran per tingkat
- Laporan prestasi per tingkat
- Grafik dan visualisasi data

## Teknologi

- **Backend**: PHP Native (tanpa framework)
- **Database**: MySQL
- **Frontend**: HTML5, CSS3, JavaScript
- **Design**: Responsive, Mobile-Friendly
- **Icons**: Font Awesome 6.4.0
- **Fonts**: Playfair Display & Source Sans Pro (Google Fonts)

## Persyaratan Sistem

- PHP 7.4 atau lebih tinggi
- MySQL 5.7 atau lebih tinggi / MariaDB
- Web Server (Apache / Nginx)
- Browser modern (Chrome, Firefox, Safari, Edge)

## Instalasi

### 1. Persiapan

**Menggunakan XAMPP:**
1. Download dan install XAMPP dari https://www.apachefriends.org/
2. Extract file `bk-system.zip` ke folder `C:\xampp\htdocs\`
3. Hasilnya: `C:\xampp\htdocs\bk-system\`

**Menggunakan WAMP/LAMP:**
1. Extract file ke folder `www` atau `html`
2. Sesuaikan path sesuai server Anda

### 2. Setup Database

1. Buka phpMyAdmin (http://localhost/phpmyadmin)
2. Buat database baru dengan nama `bk_system`
3. Import file SQL:
   - Klik database `bk_system`
   - Pilih tab "Import"
   - Browse file `database/schema.sql`
   - Klik "Go" untuk import

**Atau menggunakan MySQL Command Line:**
```bash
mysql -u root -p
CREATE DATABASE bk_system;
USE bk_system;
SOURCE /path/to/bk-system/database/schema.sql;
```

### 3. Konfigurasi Database

Edit file `config/database.php` jika perlu mengubah kredensial:

```php
private $host = "localhost";
private $db_name = "bk_system";
private $username = "root";      // Sesuaikan dengan username MySQL Anda
private $password = "";          // Sesuaikan dengan password MySQL Anda
```

### 4. Akses Aplikasi

1. Pastikan Apache dan MySQL sudah running
2. Buka browser dan akses: `http://localhost/bk-system`
3. Login dengan kredensial default:

**Admin:**
- Username: `admin`
- Password: `password`

**User/Konselor:**
- Username: `konselor`
- Password: `password`

## Struktur Folder

```
bk-system/
├── assets/
│   └── css/
│       └── style.css          # File CSS utama
├── config/
│   └── database.php           # Konfigurasi database
├── database/
│   └── schema.sql             # SQL schema dan data awal
├── includes/
│   ├── sidebar.php            # Component sidebar
│   └── topbar.php             # Component topbar
├── index.php                  # Halaman login
├── dashboard.php              # Dashboard utama
├── siswa.php                  # Manajemen data siswa
├── konseling.php              # Manajemen konseling
├── pelanggaran.php            # Manajemen pelanggaran
├── prestasi.php               # Manajemen prestasi
├── kunjungan.php              # Manajemen kunjungan
├── users.php                  # Manajemen user (admin only)
├── laporan.php                # Laporan & statistik
├── logout.php                 # Logout
└── README.md                  # Dokumentasi
```

## Panduan Penggunaan

### Login
1. Akses halaman utama
2. Masukkan username dan password
3. Klik tombol "Masuk"
4. Anda akan diarahkan ke dashboard

### Mengelola Data Siswa
1. Klik menu "Data Siswa" di sidebar
2. Klik tombol "Tambah Siswa"
3. Isi form dengan data lengkap siswa
4. Klik "Simpan"
5. Untuk edit, klik tombol "Edit" pada data siswa
6. Untuk hapus, klik tombol "Hapus" (konfirmasi akan muncul)

### Menambah Konseling
1. Klik menu "Konseling" di sidebar
2. Klik tombol "Tambah Konseling"
3. Pilih siswa dari dropdown
4. Isi tanggal, jenis konseling, kategori
5. Isi permasalahan, solusi, dan tindak lanjut
6. Pilih status konseling
7. Klik "Simpan"

### Mencatat Pelanggaran
1. Klik menu "Pelanggaran" di sidebar
2. Klik tombol "Tambah Pelanggaran"
3. Pilih siswa yang melakukan pelanggaran
4. Isi detail pelanggaran
5. Tentukan tingkat (Ringan/Sedang/Berat)
6. Isi poin dan sanksi
7. Klik "Simpan"

### Mencatat Prestasi
1. Klik menu "Prestasi" di sidebar
2. Klik tombol "Tambah Prestasi"
3. Pilih siswa berprestasi
4. Isi jenis prestasi dan tingkat
5. Isi peringkat dan penyelenggara
6. Klik "Simpan"

### Melihat Laporan
1. Klik menu "Laporan" di sidebar
2. Lihat statistik keseluruhan di bagian atas
3. Scroll untuk melihat detail per kategori
4. Tombol export (akan dikembangkan)

### Manajemen User (Admin Only)
1. Login sebagai admin
2. Klik menu "Manajemen User"
3. Klik "Tambah User" untuk menambah user baru
4. Isi username, password, nama, email, dan role
5. Klik "Simpan"

## Keamanan

### Password
- Password di-hash menggunakan `password_hash()` PHP
- Algoritma: bcrypt (PASSWORD_DEFAULT)
- Password default untuk demo: `password`
- **PENTING**: Segera ganti password default setelah instalasi!

### Session
- Sistem menggunakan PHP session untuk autentikasi
- Session otomatis expire ketika browser ditutup
- Logout akan menghapus semua session

### SQL Injection Protection
- Menggunakan PDO Prepared Statements
- Parameter binding untuk semua query
- Validasi input di sisi server

## Troubleshooting

### Error: Connection failed
**Solusi:**
1. Pastikan MySQL service berjalan
2. Cek kredensial database di `config/database.php`
3. Pastikan database `bk_system` sudah dibuat

### Halaman blank/error 500
**Solusi:**
1. Aktifkan error reporting di PHP
2. Cek file `php.ini`: `display_errors = On`
3. Restart Apache
4. Cek error log Apache

### CSS/JS tidak load
**Solusi:**
1. Pastikan path folder benar
2. Cek permission folder (chmod 755)
3. Clear browser cache
4. Periksa console browser untuk error

### Login gagal padahal kredensial benar
**Solusi:**
1. Pastikan tabel `users` terisi
2. Re-import file `schema.sql`
3. Cek apakah password ter-hash dengan benar

## Pengembangan Lebih Lanjut

### Fitur yang dapat ditambahkan:
- Export data ke Excel/PDF
- Notifikasi email/SMS
- Grafik dan chart interaktif
- Upload file dokumen
- Backup otomatis database
- Multi-language support
- API untuk integrasi dengan sistem lain
- Mobile app (Android/iOS)

### Customization:
- **Warna tema**: Edit variabel CSS di `assets/css/style.css`
- **Logo**: Tambahkan logo di `sidebar-header`
- **Tambah field**: Modifikasi table di database dan form terkait

## Lisensi

Sistem ini dibuat untuk keperluan pendidikan dan dapat digunakan secara bebas.

## Support & Kontak

Jika ada pertanyaan atau butuh bantuan:
- Email: support@example.com
- Website: https://example.com

## Changelog

### Version 1.0.0 (2026-01-29)
- Initial release
- Fitur CRUD lengkap untuk semua modul
- Dashboard dengan statistik real-time
- Role-based access control
- Responsive design
- Modern UI/UX

---

**Catatan Penting:**
1. Selalu backup database secara berkala
2. Ganti password default setelah instalasi
3. Update PHP dan MySQL ke versi terbaru
4. Jangan expose kredensial database
5. Gunakan HTTPS untuk production

---

Dikembangkan dengan ❤️ untuk pendidikan yang lebih baik.
