<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$page_title = "Data Pelanggaran";
$page_subtitle = "Manajemen pelanggaran siswa";

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $query = "INSERT INTO pelanggaran (siswa_id, tanggal_pelanggaran, jenis_pelanggaran, tingkat_pelanggaran, deskripsi, sanksi, poin, status, created_by) 
             VALUES (:siswa_id, :tanggal, :jenis, :tingkat, :deskripsi, :sanksi, :poin, :status, :created_by)";
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':siswa_id' => $_POST['siswa_id'],
        ':tanggal' => $_POST['tanggal_pelanggaran'],
        ':jenis' => $_POST['jenis_pelanggaran'],
        ':tingkat' => $_POST['tingkat_pelanggaran'],
        ':deskripsi' => $_POST['deskripsi'],
        ':sanksi' => $_POST['sanksi'],
        ':poin' => $_POST['poin'],
        ':status' => $_POST['status'],
        ':created_by' => $_SESSION['user_id']
    ]);
    $success_message = "Data pelanggaran berhasil ditambahkan!";
}

$query = "SELECT p.*, s.nama_lengkap, s.nis, s.kelas FROM pelanggaran p 
          JOIN siswa s ON p.siswa_id = s.id ORDER BY p.tanggal_pelanggaran DESC";
$pelanggaran = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

$siswa_list = $db->query("SELECT id, nis, nama_lengkap, kelas FROM siswa ORDER BY nama_lengkap")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .btn-primary{padding:12px 24px;background:var(--primary);color:var(--white);border:none;border-radius:12px;cursor:pointer;font-weight:600;transition:all .3s ease;display:inline-flex;align-items:center;gap:8px}.btn-primary:hover{background:var(--primary-light);transform:translateY(-2px);box-shadow:0 4px 12px rgba(26,71,42,.3)}.table-container{background:var(--white);border-radius:16px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05)}table{width:100%;border-collapse:collapse}thead{background:var(--primary);color:var(--white)}th{padding:18px 20px;text-align:left;font-weight:600;text-transform:uppercase;font-size:13px}td{padding:18px 20px;border-bottom:1px solid var(--border)}tbody tr:hover{background:var(--bg)}.badge{display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600}.badge-ringan{background:rgba(243,156,18,.1);color:var(--warning)}.badge-sedang{background:rgba(52,152,219,.1);color:var(--info)}.badge-berat{background:rgba(231,76,60,.1);color:var(--danger)}.status-pending{background:rgba(243,156,18,.1);color:var(--warning)}.status-proses{background:rgba(52,152,219,.1);color:var(--info)}.status-selesai{background:rgba(39,174,96,.1);color:var(--success)}.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.6);z-index:2000;align-items:center;justify-content:center}.modal.active{display:flex}.modal-content{background:var(--white);border-radius:16px;padding:35px;max-width:700px;width:90%;max-height:90vh;overflow-y:auto}.form-group{margin-bottom:20px}.form-group label{display:block;margin-bottom:8px;color:var(--text);font-weight:600;font-size:14px}.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:2px solid var(--border);border-radius:10px;font-size:15px;font-family:'Source Sans Pro',sans-serif}.form-row{display:grid;grid-template-columns:1fr 1fr;gap:20px}.modal-footer{display:flex;gap:10px;justify-content:flex-end;margin-top:25px}.btn-cancel{padding:12px 24px;background:var(--border);color:var(--text);border:none;border-radius:10px;cursor:pointer;font-weight:600}.success-message{background:rgba(39,174,96,.1);border-left:4px solid var(--success);color:var(--success);padding:16px 20px;border-radius:8px;margin-bottom:20px}
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>
            <?php if(isset($success_message)): ?>
                <div class="success-message"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
            <?php endif; ?>
            <div style="margin-bottom:25px">
                <button class="btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Tambah Pelanggaran</button>
            </div>
            <div class="table-container">
                <table>
                    <thead><tr><th>Tanggal</th><th>Siswa</th><th>Jenis Pelanggaran</th><th>Tingkat</th><th>Poin</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach($pelanggaran as $p): ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($p['tanggal_pelanggaran'])); ?></td>
                                <td><strong><?php echo htmlspecialchars($p['nama_lengkap']); ?></strong><br><small><?php echo $p['nis'].' - '.$p['kelas']; ?></small></td>
                                <td><?php echo htmlspecialchars($p['jenis_pelanggaran']); ?></td>
                                <td><span class="badge badge-<?php echo strtolower($p['tingkat_pelanggaran']); ?>"><?php echo $p['tingkat_pelanggaran']; ?></span></td>
                                <td><strong><?php echo $p['poin']; ?></strong></td>
                                <td><span class="badge status-<?php echo strtolower($p['status']); ?>"><?php echo $p['status']; ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <div id="pelanggaranModal" class="modal">
        <div class="modal-content">
            <h2 style="margin-bottom:25px;font-family:'Playfair Display',serif">Tambah Data Pelanggaran</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label>Pilih Siswa *</label>
                    <select name="siswa_id" required>
                        <option value="">-- Pilih Siswa --</option>
                        <?php foreach($siswa_list as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo $s['nis'].' - '.$s['nama_lengkap'].' ('.$s['kelas'].')'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Tanggal *</label><input type="date" name="tanggal_pelanggaran" required></div>
                    <div class="form-group"><label>Poin *</label><input type="number" name="poin" value="0" required></div>
                </div>
                <div class="form-group"><label>Jenis Pelanggaran *</label><input type="text" name="jenis_pelanggaran" required></div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Tingkat *</label>
                        <select name="tingkat_pelanggaran" required>
                            <option value="Ringan">Ringan</option>
                            <option value="Sedang">Sedang</option>
                            <option value="Berat">Berat</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="Pending">Pending</option>
                            <option value="Proses">Proses</option>
                            <option value="Selesai">Selesai</option>
                        </select>
                    </div>
                </div>
                <div class="form-group"><label>Deskripsi *</label><textarea name="deskripsi" rows="3" required></textarea></div>
                <div class="form-group"><label>Sanksi</label><textarea name="sanksi" rows="3"></textarea></div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function openModal(){document.getElementById('pelanggaranModal').classList.add('active')}
        function closeModal(){document.getElementById('pelanggaranModal').classList.remove('active')}
        window.onclick=e=>{if(e.target.classList.contains('modal'))e.target.classList.remove('active')}
    </script>
</body>
</html>
