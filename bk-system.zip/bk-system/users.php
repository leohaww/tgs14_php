<?php
session_start();
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    if($_SESSION['role'] == 'konselor') {
        header("Location: konselor-dashboard.php");
    } else {
        header("Location: dashboard.php");
    }
    exit();
}
require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$page_title = "Manajemen User";
$page_subtitle = "Kelola akun pengguna sistem";

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $query = "INSERT INTO users (username, password, full_name, email, role) VALUES (:username, :password, :full_name, :email, :role)";
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':username' => $_POST['username'],
        ':password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
        ':full_name' => $_POST['full_name'],
        ':email' => $_POST['email'],
        ':role' => $_POST['role']
    ]);
    $success_message = "User berhasil ditambahkan!";
}

$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>.btn-primary{padding:12px 24px;background:var(--primary);color:var(--white);border:none;border-radius:12px;cursor:pointer;font-weight:600;transition:all .3s;display:inline-flex;align-items:center;gap:8px}.table-container{background:var(--white);border-radius:16px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05)}table{width:100%;border-collapse:collapse}thead{background:var(--primary);color:var(--white)}th{padding:18px 20px;text-align:left;font-weight:600;text-transform:uppercase;font-size:13px}td{padding:18px 20px;border-bottom:1px solid var(--border)}tbody tr:hover{background:var(--bg)}.badge{display:inline-block;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:600}.badge-admin{background:rgba(231,76,60,.1);color:var(--danger)}.badge-user{background:rgba(52,152,219,.1);color:var(--info)}.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.6);z-index:2000;align-items:center;justify-content:center}.modal.active{display:flex}.modal-content{background:var(--white);border-radius:16px;padding:35px;max-width:600px;width:90%;max-height:90vh;overflow-y:auto}.form-group{margin-bottom:20px}.form-group label{display:block;margin-bottom:8px;color:var(--text);font-weight:600;font-size:14px}.form-group input,.form-group select{width:100%;padding:12px 16px;border:2px solid var(--border);border-radius:10px;font-size:15px;font-family:'Source Sans Pro',sans-serif}.modal-footer{display:flex;gap:10px;justify-content:flex-end;margin-top:25px}.btn-cancel{padding:12px 24px;background:var(--border);color:var(--text);border:none;border-radius:10px;cursor:pointer;font-weight:600}.success-message{background:rgba(39,174,96,.1);border-left:4px solid var(--success);color:var(--success);padding:16px 20px;border-radius:8px;margin-bottom:20px}</style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>
            <?php if(isset($success_message)): ?><div class="success-message"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div><?php endif; ?>
            <div style="margin-bottom:25px"><button class="btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Tambah User</button></div>
            <div class="table-container">
                <table>
                    <thead><tr><th>Username</th><th>Nama Lengkap</th><th>Email</th><th>Role</th><th>Terdaftar</th></tr></thead>
                    <tbody>
                        <?php foreach($users as $u): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($u['username']); ?></strong></td>
                                <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($u['email']); ?></td>
                                <td><span class="badge badge-<?php echo $u['role']; ?>"><?php echo strtoupper($u['role']); ?></span></td>
                                <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <div id="userModal" class="modal">
        <div class="modal-content">
            <h2 style="margin-bottom:25px;font-family:'Playfair Display',serif">Tambah User Baru</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-group"><label>Username *</label><input type="text" name="username" required></div>
                <div class="form-group"><label>Password *</label><input type="password" name="password" required></div>
                <div class="form-group"><label>Nama Lengkap *</label><input type="text" name="full_name" required></div>
                <div class="form-group"><label>Email *</label><input type="email" name="email" required></div>
                <div class="form-group">
                    <label>Role *</label>
                    <select name="role" required>
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
    <script>function openModal(){document.getElementById('userModal').classList.add('active')}function closeModal(){document.getElementById('userModal').classList.remove('active')}window.onclick=e=>{if(e.target.classList.contains('modal'))e.target.classList.remove('active')}</script>
</body>
</html>
