<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['action'])) {
        if($_POST['action'] == 'add') {
            $query = "INSERT INTO siswa (nis, nama_lengkap, jenis_kelamin, kelas, tahun_ajaran, tanggal_lahir, alamat, no_telp, email, nama_wali, no_telp_wali) 
                     VALUES (:nis, :nama_lengkap, :jenis_kelamin, :kelas, :tahun_ajaran, :tanggal_lahir, :alamat, :no_telp, :email, :nama_wali, :no_telp_wali)";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':nis', $_POST['nis']);
            $stmt->bindParam(':nama_lengkap', $_POST['nama_lengkap']);
            $stmt->bindParam(':jenis_kelamin', $_POST['jenis_kelamin']);
            $stmt->bindParam(':kelas', $_POST['kelas']);
            $stmt->bindParam(':tahun_ajaran', $_POST['tahun_ajaran']);
            $stmt->bindParam(':tanggal_lahir', $_POST['tanggal_lahir']);
            $stmt->bindParam(':alamat', $_POST['alamat']);
            $stmt->bindParam(':no_telp', $_POST['no_telp']);
            $stmt->bindParam(':email', $_POST['email']);
            $stmt->bindParam(':nama_wali', $_POST['nama_wali']);
            $stmt->bindParam(':no_telp_wali', $_POST['no_telp_wali']);
            
            if($stmt->execute()) {
                $success_message = "Data siswa berhasil ditambahkan!";
            }
        } elseif($_POST['action'] == 'edit') {
            $query = "UPDATE siswa SET 
                     nama_lengkap = :nama_lengkap,
                     jenis_kelamin = :jenis_kelamin,
                     kelas = :kelas,
                     tahun_ajaran = :tahun_ajaran,
                     tanggal_lahir = :tanggal_lahir,
                     alamat = :alamat,
                     no_telp = :no_telp,
                     email = :email,
                     nama_wali = :nama_wali,
                     no_telp_wali = :no_telp_wali
                     WHERE id = :id";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $_POST['id']);
            $stmt->bindParam(':nama_lengkap', $_POST['nama_lengkap']);
            $stmt->bindParam(':jenis_kelamin', $_POST['jenis_kelamin']);
            $stmt->bindParam(':kelas', $_POST['kelas']);
            $stmt->bindParam(':tahun_ajaran', $_POST['tahun_ajaran']);
            $stmt->bindParam(':tanggal_lahir', $_POST['tanggal_lahir']);
            $stmt->bindParam(':alamat', $_POST['alamat']);
            $stmt->bindParam(':no_telp', $_POST['no_telp']);
            $stmt->bindParam(':email', $_POST['email']);
            $stmt->bindParam(':nama_wali', $_POST['nama_wali']);
            $stmt->bindParam(':no_telp_wali', $_POST['no_telp_wali']);
            
            if($stmt->execute()) {
                $success_message = "Data siswa berhasil diperbarui!";
            }
        } elseif($_POST['action'] == 'delete') {
            $query = "DELETE FROM siswa WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':id', $_POST['id']);
            
            if($stmt->execute()) {
                $success_message = "Data siswa berhasil dihapus!";
            }
        }
    }
}

// Get all students
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM siswa WHERE nama_lengkap LIKE :search OR nis LIKE :search ORDER BY nama_lengkap ASC";
$stmt = $db->prepare($query);
$search_param = "%$search%";
$stmt->bindParam(':search', $search_param);
$stmt->execute();
$siswa = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            gap: 15px;
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 45px 12px 20px;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(26, 71, 42, 0.1);
        }

        .search-box i {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }

        .btn-primary {
            padding: 12px 24px;
            background: var(--primary);
            color: var(--white);
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-primary:hover {
            background: var(--primary-light);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(26, 71, 42, 0.3);
        }

        .table-container {
            background: var(--white);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: var(--primary);
            color: var(--white);
        }

        th {
            padding: 18px 20px;
            text-align: left;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 13px;
            letter-spacing: 0.5px;
        }

        td {
            padding: 18px 20px;
            border-bottom: 1px solid var(--border);
        }

        tbody tr {
            transition: background 0.3s ease;
        }

        tbody tr:hover {
            background: var(--bg);
        }

        .btn-action {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s ease;
            margin-right: 5px;
        }

        .btn-edit {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .btn-edit:hover {
            background: var(--info);
            color: var(--white);
        }

        .btn-delete {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }

        .btn-delete:hover {
            background: var(--danger);
            color: var(--white);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            border-radius: 16px;
            padding: 35px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlide 0.3s ease;
        }

        @keyframes modalSlide {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border);
        }

        .modal-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            color: var(--text);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text);
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 15px;
            font-family: 'Source Sans Pro', sans-serif;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(26, 71, 42, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .modal-footer {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
        }

        .btn-cancel {
            padding: 12px 24px;
            background: var(--border);
            color: var(--text);
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }

        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-male {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .badge-female {
            background: rgba(233, 30, 99, 0.1);
            color: #e91e63;
        }

        .success-message {
            background: rgba(39, 174, 96, 0.1);
            border-left: 4px solid var(--success);
            color: var(--success);
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>

    <main class="main-content">
        <?php include 'includes/topbar.php'; ?>

        <?php if(isset($success_message)): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <div class="action-bar">
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Cari siswa (nama atau NIS)..." value="<?php echo htmlspecialchars($search); ?>">
                <i class="fas fa-search"></i>
            </div>
            <button class="btn-primary" onclick="openModal('add')">
                <i class="fas fa-plus"></i> Tambah Siswa
            </button>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>NIS</th>
                        <th>Nama Lengkap</th>
                        <th>L/P</th>
                        <th>Kelas</th>
                        <th>Tahun Ajaran</th>
                        <th>No. Telp</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($siswa) > 0): ?>
                        <?php foreach($siswa as $s): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($s['nis']); ?></strong></td>
                                <td><?php echo htmlspecialchars($s['nama_lengkap']); ?></td>
                                <td>
                                    <span class="badge <?php echo $s['jenis_kelamin'] == 'L' ? 'badge-male' : 'badge-female'; ?>">
                                        <?php echo $s['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($s['kelas']); ?></td>
                                <td><?php echo htmlspecialchars($s['tahun_ajaran']); ?></td>
                                <td><?php echo htmlspecialchars($s['no_telp']); ?></td>
                                <td>
                                    <button class="btn-action btn-edit" onclick='editSiswa(<?php echo json_encode($s); ?>)'>
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <a href="detail-siswa.php?id=<?php echo $s['id']; ?>" class="btn-action" style="background:rgba(52,152,219,.1);color:var(--info);text-decoration:none">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                    <button class="btn-action btn-delete" onclick="deleteSiswa(<?php echo $s['id']; ?>, '<?php echo htmlspecialchars($s['nama_lengkap']); ?>')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-light);">
                                <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; opacity: 0.3;"></i>
                                <p>Tidak ada data siswa</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Modal Add/Edit -->
    <div id="siswaModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Tambah Data Siswa</h2>
            </div>
            <form id="siswaForm" method="POST">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="id" id="siswaId">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>NIS *</label>
                        <input type="text" name="nis" id="nis" required>
                    </div>
                    <div class="form-group">
                        <label>Tahun Ajaran *</label>
                        <input type="text" name="tahun_ajaran" id="tahun_ajaran" placeholder="2024/2025" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" id="nama_lengkap" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Jenis Kelamin *</label>
                        <select name="jenis_kelamin" id="jenis_kelamin" required>
                            <option value="">Pilih</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" id="tanggal_lahir">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Kelas *</label>
                        <input type="text" name="kelas" id="kelas" placeholder="X IPA 1" required>
                    </div>
                    <div class="form-group">
                        <label>No. Telepon</label>
                        <input type="text" name="no_telp" id="no_telp">
                    </div>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="email">
                </div>

                <div class="form-group">
                    <label>Alamat</label>
                    <textarea name="alamat" id="alamat" rows="3"></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Nama Wali</label>
                        <input type="text" name="nama_wali" id="nama_wali">
                    </div>
                    <div class="form-group">
                        <label>No. Telp Wali</label>
                        <input type="text" name="no_telp_wali" id="no_telp_wali">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h2>Konfirmasi Hapus</h2>
            </div>
            <p style="margin-bottom: 25px;">Apakah Anda yakin ingin menghapus data siswa <strong id="deleteName"></strong>?</p>
            <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="deleteId">
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeDeleteModal()">Batal</button>
                    <button type="submit" class="btn-action btn-delete">
                        <i class="fas fa-trash"></i> Hapus
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function(e) {
            if(e.key === 'Enter') {
                window.location.href = 'siswa.php?search=' + this.value;
            }
        });

        function openModal(action) {
            document.getElementById('siswaModal').classList.add('active');
            document.getElementById('formAction').value = action;
            
            if(action === 'add') {
                document.getElementById('modalTitle').textContent = 'Tambah Data Siswa';
                document.getElementById('siswaForm').reset();
            }
        }

        function closeModal() {
            document.getElementById('siswaModal').classList.remove('active');
        }

        function editSiswa(data) {
            document.getElementById('modalTitle').textContent = 'Edit Data Siswa';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('siswaId').value = data.id;
            document.getElementById('nis').value = data.nis;
            document.getElementById('nama_lengkap').value = data.nama_lengkap;
            document.getElementById('jenis_kelamin').value = data.jenis_kelamin;
            document.getElementById('kelas').value = data.kelas;
            document.getElementById('tahun_ajaran').value = data.tahun_ajaran;
            document.getElementById('tanggal_lahir').value = data.tanggal_lahir;
            document.getElementById('alamat').value = data.alamat;
            document.getElementById('no_telp').value = data.no_telp;
            document.getElementById('email').value = data.email;
            document.getElementById('nama_wali').value = data.nama_wali;
            document.getElementById('no_telp_wali').value = data.no_telp_wali;
            
            document.getElementById('nis').readOnly = true;
            openModal('edit');
        }

        function deleteSiswa(id, name) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteName').textContent = name;
            document.getElementById('deleteModal').classList.add('active');
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.remove('active');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if(event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>
