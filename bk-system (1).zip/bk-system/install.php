<?php
/**
 * INSTALLER - Sistem Administrasi Bimbingan Konseling
 * File ini hanya perlu dijalankan sekali untuk setup database
 * Setelah berhasil, hapus file ini untuk keamanan
 */

$errors = [];
$success = false;

// Database Configuration
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "bk_system";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Connect to MySQL (without database)
        $conn = new PDO("mysql:host=$db_host", $db_user, $db_pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Create database
        $conn->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        
        // Connect to the new database
        $conn->exec("USE `$db_name`");
        
        // Read and execute SQL file
        $sql_file = __DIR__ . '/database/schema.sql';
        
        if(!file_exists($sql_file)) {
            throw new Exception("File schema.sql tidak ditemukan di folder database/");
        }
        
        $sql = file_get_contents($sql_file);
        
        // Split SQL by semicolon and execute each statement
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        
        foreach($statements as $statement) {
            if(!empty($statement)) {
                $conn->exec($statement);
            }
        }
        
        $success = true;
        
    } catch(PDOException $e) {
        $errors[] = "Database Error: " . $e->getMessage();
    } catch(Exception $e) {
        $errors[] = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installer - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Source Sans Pro', sans-serif;
            background: linear-gradient(135deg, #1a472a 0%, #2d5f3f 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .installer-box {
            background: white;
            border-radius: 16px;
            padding: 40px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }
        
        h1 {
            font-family: 'Playfair Display', serif;
            color: #1a472a;
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #6c7a89;
            margin-bottom: 30px;
        }
        
        .info-box {
            background: #f8f9fa;
            border-left: 4px solid #1a472a;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
        }
        
        .info-box h3 {
            color: #1a472a;
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        .info-box p {
            color: #6c7a89;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        
        .info-box ul {
            margin-left: 20px;
            color: #6c7a89;
        }
        
        .info-box ul li {
            margin-bottom: 5px;
        }
        
        .config-info {
            background: #e8f4f8;
            border-left: 4px solid #3498db;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-family: monospace;
            font-size: 14px;
        }
        
        .config-info strong {
            color: #2c3e50;
        }
        
        .error-box {
            background: #fee;
            border-left: 4px solid #e74c3c;
            color: #c0392b;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .success-box {
            background: #eef;
            border-left: 4px solid #27ae60;
            color: #27ae60;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .success-box h3 {
            margin-bottom: 10px;
            font-size: 20px;
        }
        
        .btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #1a472a 0%, #2d5f3f 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(26, 71, 42, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        }
        
        .warning {
            background: #fff3cd;
            border-left: 4px solid #f39c12;
            color: #856404;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .step-number {
            display: inline-block;
            width: 30px;
            height: 30px;
            background: #1a472a;
            color: white;
            border-radius: 50%;
            text-align: center;
            line-height: 30px;
            margin-right: 10px;
            font-weight: bold;
        }
        
        code {
            background: #f8f9fa;
            padding: 2px 6px;
            border-radius: 4px;
            color: #e74c3c;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="installer-box">
        <h1>🎓 Installer Sistem BK</h1>
        <p class="subtitle">Setup Database - Sistem Administrasi Bimbingan Konseling</p>
        
        <?php if(!$success && empty($errors)): ?>
            <div class="info-box">
                <h3>📋 Informasi</h3>
                <p>Installer ini akan melakukan setup otomatis:</p>
                <ul>
                    <li>Membuat database <strong>bk_system</strong></li>
                    <li>Membuat 6 tabel (users, siswa, konseling, pelanggaran, prestasi, kunjungan)</li>
                    <li>Menambahkan 2 user default (admin & konselor)</li>
                </ul>
            </div>
            
            <div class="config-info">
                <strong>Konfigurasi Database:</strong><br>
                Host: <?php echo $db_host; ?><br>
                Username: <?php echo $db_user; ?><br>
                Password: <?php echo empty($db_pass) ? '(kosong)' : '******'; ?><br>
                Database: <?php echo $db_name; ?>
            </div>
            
            <div class="info-box">
                <h3>⚙️ Persyaratan</h3>
                <ul>
                    <li>✅ XAMPP/WAMP sudah terinstall</li>
                    <li>✅ Apache dan MySQL sudah berjalan</li>
                    <li>✅ Folder <code>database/schema.sql</code> tersedia</li>
                </ul>
            </div>
            
            <form method="POST">
                <button type="submit" class="btn">
                    🚀 Mulai Instalasi
                </button>
            </form>
            
            <div class="warning">
                ⚠️ <strong>Penting:</strong> Jika database <code>bk_system</code> sudah ada, data lama akan ditimpa!
            </div>
            
        <?php elseif(!empty($errors)): ?>
            <div class="error-box">
                <strong>❌ Error!</strong><br><br>
                <?php foreach($errors as $error): ?>
                    <?php echo $error; ?><br>
                <?php endforeach; ?>
            </div>
            
            <div class="info-box">
                <h3>💡 Solusi:</h3>
                <p><span class="step-number">1</span> Pastikan MySQL sudah berjalan di XAMPP/WAMP</p>
                <p><span class="step-number">2</span> Periksa username dan password MySQL di file <code>config/database.php</code></p>
                <p><span class="step-number">3</span> Pastikan file <code>database/schema.sql</code> ada</p>
            </div>
            
            <form method="POST">
                <button type="submit" class="btn">
                    🔄 Coba Lagi
                </button>
            </form>
            
        <?php else: ?>
            <div class="success-box">
                <h3>✅ Instalasi Berhasil!</h3>
                <p>Database berhasil dibuat dan siap digunakan.</p>
            </div>
            
            <div class="info-box">
                <h3>🎯 Langkah Selanjutnya:</h3>
                <p><span class="step-number">1</span> Hapus file <code>install.php</code> ini untuk keamanan</p>
                <p><span class="step-number">2</span> Akses aplikasi di: <code>index.php</code></p>
                <p><span class="step-number">3</span> Login dengan kredensial berikut:</p>
            </div>
            
            <div class="config-info">
                <strong>👤 Admin:</strong><br>
                Username: admin<br>
                Password: password<br><br>
                <strong>👤 User/Konselor:</strong><br>
                Username: konselor<br>
                Password: password
            </div>
            
            <div class="warning">
                🔒 <strong>Keamanan:</strong> Segera ubah password default setelah login pertama!
            </div>
            
            <a href="index.php" style="text-decoration: none;">
                <button type="button" class="btn btn-success" style="margin-top: 20px;">
                    ➡️ Buka Aplikasi
                </button>
            </a>
        <?php endif; ?>
    </div>
</body>
</html>
