<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$page_title = "Data Kunjungan";
$page_subtitle = "Manajemen kunjungan siswa";

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $query = "INSERT INTO kunjungan (siswa_id, tanggal_kunjungan, tujuan_kunjungan, hasil_kunjungan, petugas_id) 
             VALUES (:siswa_id, :tanggal, :tujuan, :hasil, :petugas)";
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':siswa_id' => $_POST['siswa_id'],
        ':tanggal' => $_POST['tanggal_kunjungan'],
        ':tujuan' => $_POST['tujuan_kunjungan'],
        ':hasil' => $_POST['hasil_kunjungan'],
        ':petugas' => $_SESSION['user_id']
    ]);
    $success_message = "Data kunjungan berhasil ditambahkan!";
}

$query = "SELECT k.*, s.nama_lengkap, s.nis, s.kelas, u.full_name as petugas FROM kunjungan k 
          JOIN siswa s ON k.siswa_id = s.id 
          JOIN users u ON k.petugas_id = u.id
          ORDER BY k.tanggal_kunjungan DESC";
$kunjungan = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
$siswa_list = $db->query("SELECT id, nis, nama_lengkap, kelas FROM siswa ORDER BY nama_lengkap")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>.btn-primary{padding:12px 24px;background:var(--primary);color:var(--white);border:none;border-radius:12px;cursor:pointer;font-weight:600;transition:all .3s;display:inline-flex;align-items:center;gap:8px}.btn-primary:hover{background:var(--primary-light);transform:translateY(-2px);box-shadow:0 4px 12px rgba(26,71,42,.3)}.table-container{background:var(--white);border-radius:16px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05)}table{width:100%;border-collapse:collapse}thead{background:var(--primary);color:var(--white)}th{padding:18px 20px;text-align:left;font-weight:600;text-transform:uppercase;font-size:13px}td{padding:18px 20px;border-bottom:1px solid var(--border)}tbody tr:hover{background:var(--bg)}.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.6);z-index:2000;align-items:center;justify-content:center}.modal.active{display:flex}.modal-content{background:var(--white);border-radius:16px;padding:35px;max-width:700px;width:90%;max-height:90vh;overflow-y:auto}.form-group{margin-bottom:20px}.form-group label{display:block;margin-bottom:8px;color:var(--text);font-weight:600;font-size:14px}.form-group input,.form-group select,.form-group textarea{width:100%;padding:12px 16px;border:2px solid var(--border);border-radius:10px;font-size:15px;font-family:'Source Sans Pro',sans-serif}.form-row{display:grid;grid-template-columns:1fr 1fr;gap:20px}.modal-footer{display:flex;gap:10px;justify-content:flex-end;margin-top:25px}.btn-cancel{padding:12px 24px;background:var(--border);color:var(--text);border:none;border-radius:10px;cursor:pointer;font-weight:600}.success-message{background:rgba(39,174,96,.1);border-left:4px solid var(--success);color:var(--success);padding:16px 20px;border-radius:8px;margin-bottom:20px}</style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>
            <?php if(isset($success_message)): ?><div class="success-message"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div><?php endif; ?>
            <div style="margin-bottom:25px"><button class="btn-primary" onclick="openModal()"><i class="fas fa-plus"></i> Tambah Kunjungan</button></div>
            <div class="table-container">
                <table>
                    <thead><tr><th>Tanggal</th><th>Siswa</th><th>Tujuan Kunjungan</th><th>Hasil</th><th>Petugas</th></tr></thead>
                    <tbody>
                        <?php foreach($kunjungan as $k): ?>
                            <tr>
                                <td><?php echo date('d M Y H:i', strtotime($k['tanggal_kunjungan'])); ?></td>
                                <td><strong><?php echo htmlspecialchars($k['nama_lengkap']); ?></strong><br><small><?php echo $k['nis'].' - '.$k['kelas']; ?></small></td>
                                <td><?php echo htmlspecialchars(substr($k['tujuan_kunjungan'], 0, 80)); ?>...</td>
                                <td><?php echo htmlspecialchars(substr($k['hasil_kunjungan'] ?? '-', 0, 80)); ?></td>
                                <td><?php echo htmlspecialchars($k['petugas']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <div id="kunjunganModal" class="modal">
        <div class="modal-content">
            <h2 style="margin-bottom:25px;font-family:'Playfair Display',serif">Tambah Data Kunjungan</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label>Pilih Siswa *</label>
                    <select name="siswa_id" required>
                        <option value="">-- Pilih Siswa --</option>
                        <?php foreach($siswa_list as $s): ?>
                            <option value="<?php echo $s['id']; ?>"><?php echo $s['nis'].' - '.$s['nama_lengkap'].' ('.$s['kelas'].')'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Tanggal & Waktu Kunjungan *</label><input type="datetime-local" name="tanggal_kunjungan" required></div>
                <div class="form-group"><label>Tujuan Kunjungan *</label><textarea name="tujuan_kunjungan" rows="4" required></textarea></div>
                <div class="form-group"><label>Hasil Kunjungan</label><textarea name="hasil_kunjungan" rows="4"></textarea></div>
                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
    <script>function openModal(){document.getElementById('kunjunganModal').classList.add('active')}function closeModal(){document.getElementById('kunjunganModal').classList.remove('active')}window.onclick=e=>{if(e.target.classList.contains('modal'))e.target.classList.remove('active')}</script>
</body>
</html>
