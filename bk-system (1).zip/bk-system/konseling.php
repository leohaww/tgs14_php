<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$page_title = "Data Konseling";
$page_subtitle = "Manajemen sesi konseling siswa";

// Handle form submissions
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if($_POST['action'] == 'add') {
        $query = "INSERT INTO konseling (siswa_id, konselor_id, tanggal_konseling, jenis_konseling, kategori, permasalahan, solusi, tindak_lanjut, status, catatan) 
                 VALUES (:siswa_id, :konselor_id, :tanggal_konseling, :jenis_konseling, :kategori, :permasalahan, :solusi, :tindak_lanjut, :status, :catatan)";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':siswa_id', $_POST['siswa_id']);
        $stmt->bindParam(':konselor_id', $_SESSION['user_id']);
        $stmt->bindParam(':tanggal_konseling', $_POST['tanggal_konseling']);
        $stmt->bindParam(':jenis_konseling', $_POST['jenis_konseling']);
        $stmt->bindParam(':kategori', $_POST['kategori']);
        $stmt->bindParam(':permasalahan', $_POST['permasalahan']);
        $stmt->bindParam(':solusi', $_POST['solusi']);
        $stmt->bindParam(':tindak_lanjut', $_POST['tindak_lanjut']);
        $stmt->bindParam(':status', $_POST['status']);
        $stmt->bindParam(':catatan', $_POST['catatan']);
        
        if($stmt->execute()) {
            $success_message = "Data konseling berhasil ditambahkan!";
        }
    }
}

// Get all counseling sessions with student info
$query = "SELECT k.*, s.nama_lengkap, s.nis, s.kelas, u.full_name as konselor 
          FROM konseling k 
          JOIN siswa s ON k.siswa_id = s.id 
          JOIN users u ON k.konselor_id = u.id 
          ORDER BY k.tanggal_konseling DESC";
$stmt = $db->query($query);
$konseling = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all students for dropdown
$query_siswa = "SELECT id, nis, nama_lengkap, kelas FROM siswa ORDER BY nama_lengkap ASC";
$stmt_siswa = $db->query($query_siswa);
$siswa_list = $stmt_siswa->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .btn-primary {
            padding: 12px 24px;
            background: var(--primary);
            color: var(--white);
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary:hover {
            background: var(--primary-light);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(26, 71, 42, 0.3);
        }

        .konseling-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 24px;
        }

        .konseling-card {
            background: var(--white);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border-left: 4px solid var(--primary);
            transition: all 0.3s ease;
        }

        .konseling-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
        }

        .konseling-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }

        .konseling-header h3 {
            font-size: 18px;
            color: var(--text);
            margin-bottom: 5px;
        }

        .konseling-meta {
            font-size: 13px;
            color: var(--text-light);
            margin-bottom: 15px;
        }

        .konseling-meta i {
            margin-right: 5px;
        }

        .konseling-content {
            margin: 15px 0;
        }

        .konseling-label {
            font-size: 12px;
            text-transform: uppercase;
            color: var(--text-light);
            font-weight: 600;
            margin-bottom: 5px;
        }

        .konseling-text {
            font-size: 14px;
            color: var(--text);
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-terjadwal {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .status-selesai {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        .status-dibatalkan {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }

        .jenis-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            border-radius: 16px;
            padding: 35px;
            max-width: 700px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border);
        }

        .modal-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            color: var(--text);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text);
            font-weight: 600;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 15px;
            font-family: 'Source Sans Pro', sans-serif;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(26, 71, 42, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .modal-footer {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
        }

        .btn-cancel {
            padding: 12px 24px;
            background: var(--border);
            color: var(--text);
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }

        .success-message {
            background: rgba(39, 174, 96, 0.1);
            border-left: 4px solid var(--success);
            color: var(--success);
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .konseling-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>

            <?php if(isset($success_message)): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <div class="action-bar">
                <h2 style="font-family: 'Playfair Display', serif; color: var(--text);">
                    Total Sesi: <?php echo count($konseling); ?>
                </h2>
                <button class="btn-primary" onclick="openModal()">
                    <i class="fas fa-plus"></i> Tambah Konseling
                </button>
            </div>

            <div class="konseling-grid">
                <?php if(count($konseling) > 0): ?>
                    <?php foreach($konseling as $k): ?>
                        <div class="konseling-card">
                            <div class="konseling-header">
                                <div>
                                    <h3><?php echo htmlspecialchars($k['nama_lengkap']); ?></h3>
                                    <div class="konseling-meta">
                                        <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($k['nis']); ?> |
                                        <i class="fas fa-school"></i> <?php echo htmlspecialchars($k['kelas']); ?>
                                    </div>
                                </div>
                                <span class="jenis-badge"><?php echo $k['jenis_konseling']; ?></span>
                            </div>

                            <div class="konseling-meta">
                                <i class="fas fa-calendar"></i> <?php echo date('d M Y H:i', strtotime($k['tanggal_konseling'])); ?><br>
                                <i class="fas fa-user-tie"></i> <?php echo htmlspecialchars($k['konselor']); ?>
                            </div>

                            <div class="konseling-content">
                                <div class="konseling-label">Kategori</div>
                                <div class="konseling-text"><?php echo htmlspecialchars($k['kategori']); ?></div>

                                <div class="konseling-label">Permasalahan</div>
                                <div class="konseling-text"><?php echo htmlspecialchars(substr($k['permasalahan'], 0, 150)); ?>...</div>
                            </div>

                            <span class="status-badge status-<?php echo strtolower($k['status']); ?>">
                                <?php echo $k['status']; ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="card" style="grid-column: 1/-1;">
                        <p style="text-align: center; padding: 40px; color: var(--text-light);">
                            <i class="fas fa-inbox" style="font-size: 48px; display: block; margin-bottom: 15px; opacity: 0.3;"></i>
                            Belum ada data konseling
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Modal Add Konseling -->
    <div id="konselingModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Tambah Data Konseling</h2>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Pilih Siswa *</label>
                    <select name="siswa_id" required>
                        <option value="">-- Pilih Siswa --</option>
                        <?php foreach($siswa_list as $s): ?>
                            <option value="<?php echo $s['id']; ?>">
                                <?php echo htmlspecialchars($s['nis'] . ' - ' . $s['nama_lengkap'] . ' (' . $s['kelas'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Tanggal & Waktu Konseling *</label>
                        <input type="datetime-local" name="tanggal_konseling" required>
                    </div>
                    <div class="form-group">
                        <label>Jenis Konseling *</label>
                        <select name="jenis_konseling" required>
                            <option value="Individual">Individual</option>
                            <option value="Kelompok">Kelompok</option>
                            <option value="Klasikal">Klasikal</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Kategori *</label>
                        <input type="text" name="kategori" placeholder="Akademik/Pribadi/Sosial/Karir" required>
                    </div>
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="Terjadwal">Terjadwal</option>
                            <option value="Selesai">Selesai</option>
                            <option value="Dibatalkan">Dibatalkan</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Permasalahan *</label>
                    <textarea name="permasalahan" rows="4" required></textarea>
                </div>

                <div class="form-group">
                    <label>Solusi</label>
                    <textarea name="solusi" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label>Tindak Lanjut</label>
                    <textarea name="tindak_lanjut" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label>Catatan Tambahan</label>
                    <textarea name="catatan" rows="2"></textarea>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Batal</button>
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('konselingModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('konselingModal').classList.remove('active');
        }

        window.onclick = function(event) {
            if(event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>
