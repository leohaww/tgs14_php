<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit(); }
require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();
$page_title = "Profil Saya";
$page_subtitle = "Kelola informasi akun Anda";

$success_message = '';
$error_message = '';

// Get current user data
$query = "SELECT * FROM users WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if($_POST['action'] == 'update_profile') {
        $query = "UPDATE users SET full_name = :full_name, email = :email WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':full_name' => $_POST['full_name'],
            ':email' => $_POST['email'],
            ':id' => $_SESSION['user_id']
        ]);
        $_SESSION['full_name'] = $_POST['full_name'];
        $success_message = "Profil berhasil diperbarui!";
        
        // Refresh user data
        $stmt = $db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->bindParam(':id', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    if($_POST['action'] == 'change_password') {
        // Verify current password
        if(password_verify($_POST['current_password'], $user['password'])) {
            if($_POST['new_password'] == $_POST['confirm_password']) {
                if(strlen($_POST['new_password']) >= 6) {
                    $new_hash = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                    $query = "UPDATE users SET password = :password WHERE id = :id";
                    $stmt = $db->prepare($query);
                    $stmt->execute([':password' => $new_hash, ':id' => $_SESSION['user_id']]);
                    $success_message = "Password berhasil diubah!";
                } else {
                    $error_message = "Password minimal 6 karakter!";
                }
            } else {
                $error_message = "Password baru dan konfirmasi tidak cocok!";
            }
        } else {
            $error_message = "Password saat ini salah!";
        }
    }
}

// Get activity stats
$konseling_count = $db->prepare("SELECT COUNT(*) as c FROM konseling WHERE konselor_id = :id");
$konseling_count->execute([':id' => $_SESSION['user_id']]);
$total_konseling = $konseling_count->fetch()['c'];

$pelanggaran_count = $db->prepare("SELECT COUNT(*) as c FROM pelanggaran WHERE created_by = :id");
$pelanggaran_count->execute([':id' => $_SESSION['user_id']]);
$total_pelanggaran = $pelanggaran_count->fetch()['c'];

$prestasi_count = $db->prepare("SELECT COUNT(*) as c FROM prestasi WHERE created_by = :id");
$prestasi_count->execute([':id' => $_SESSION['user_id']]);
$total_prestasi = $prestasi_count->fetch()['c'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem BK</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Source+Sans+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .profile-grid{display:grid;grid-template-columns:1fr 2fr;gap:30px;margin-bottom:30px}.profile-card{background:var(--white);border-radius:16px;padding:40px;box-shadow:0 2px 8px rgba(0,0,0,.05);text-align:center}.profile-avatar{width:120px;height:120px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:48px;font-weight:bold;color:var(--white);margin:0 auto 20px;box-shadow:0 8px 24px rgba(26,71,42,.3)}.profile-name{font-family:'Playfair Display',serif;font-size:28px;color:var(--text);margin-bottom:8px}.profile-role{display:inline-block;padding:6px 20px;background:rgba(26,71,42,.1);color:var(--primary);border-radius:20px;font-size:14px;font-weight:600;text-transform:uppercase;margin-bottom:20px}.profile-info{text-align:left;margin-top:30px;padding-top:30px;border-top:2px solid var(--border)}.info-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border)}.info-row:last-child{border-bottom:none}.info-label{color:var(--text-light);font-weight:600}.info-value{color:var(--text);font-weight:600}.stats-mini{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;margin-top:30px}.stat-mini{text-align:center;padding:20px;background:var(--bg);border-radius:12px}.stat-mini-number{font-size:32px;font-weight:700;color:var(--primary);font-family:'Playfair Display',serif;margin-bottom:5px}.stat-mini-label{font-size:13px;color:var(--text-light);text-transform:uppercase}.form-section{background:var(--white);border-radius:16px;padding:35px;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:25px}.form-section h3{font-family:'Playfair Display',serif;font-size:22px;margin-bottom:25px;padding-bottom:15px;border-bottom:2px solid var(--border)}.form-group{margin-bottom:20px}.form-group label{display:block;margin-bottom:8px;color:var(--text);font-weight:600;font-size:14px}.form-group input{width:100%;padding:12px 16px;border:2px solid var(--border);border-radius:10px;font-size:15px;font-family:'Source Sans Pro',sans-serif;transition:all .3s}.form-group input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(26,71,42,.1)}.btn-primary{padding:12px 24px;background:var(--primary);color:var(--white);border:none;border-radius:12px;cursor:pointer;font-weight:600;transition:all .3s;display:inline-flex;align-items:center;gap:8px}.btn-primary:hover{background:var(--primary-light);transform:translateY(-2px);box-shadow:0 4px 12px rgba(26,71,42,.3)}.success-message{background:rgba(39,174,96,.1);border-left:4px solid var(--success);color:var(--success);padding:16px 20px;border-radius:8px;margin-bottom:20px}.error-message{background:rgba(231,76,60,.1);border-left:4px solid var(--danger);color:var(--danger);padding:16px 20px;border-radius:8px;margin-bottom:20px}@media(max-width:768px){.profile-grid{grid-template-columns:1fr}}
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        <main class="main-content">
            <?php include 'includes/topbar.php'; ?>
            
            <?php if($success_message): ?>
                <div class="success-message"><i class="fas fa-check-circle"></i> <?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if($error_message): ?>
                <div class="error-message"><i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?></div>
            <?php endif; ?>

            <div class="profile-grid">
                <div class="profile-card">
                    <div class="profile-avatar">
                        <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                    </div>
                    <h2 class="profile-name"><?php echo htmlspecialchars($user['full_name']); ?></h2>
                    <span class="profile-role"><?php echo $user['role']; ?></span>
                    
                    <div class="profile-info">
                        <div class="info-row">
                            <span class="info-label">Username:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['username']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['email']); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Terdaftar:</span>
                            <span class="info-value"><?php echo date('d M Y', strtotime($user['created_at'])); ?></span>
                        </div>
                    </div>

                    <div class="stats-mini">
                        <div class="stat-mini">
                            <div class="stat-mini-number"><?php echo $total_konseling; ?></div>
                            <div class="stat-mini-label">Konseling</div>
                        </div>
                        <div class="stat-mini">
                            <div class="stat-mini-number"><?php echo $total_pelanggaran; ?></div>
                            <div class="stat-mini-label">Pelanggaran</div>
                        </div>
                        <div class="stat-mini">
                            <div class="stat-mini-number"><?php echo $total_prestasi; ?></div>
                            <div class="stat-mini-label">Prestasi</div>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="form-section">
                        <h3><i class="fas fa-user-edit"></i> Edit Profil</h3>
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                <small style="color:var(--text-light);font-size:13px">Username tidak dapat diubah</small>
                            </div>
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                            <button type="submit" class="btn-primary">
                                <i class="fas fa-save"></i> Simpan Perubahan
                            </button>
                        </form>
                    </div>

                    <div class="form-section">
                        <h3><i class="fas fa-lock"></i> Ubah Password</h3>
                        <form method="POST">
                            <input type="hidden" name="action" value="change_password">
                            <div class="form-group">
                                <label>Password Saat Ini</label>
                                <input type="password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label>Password Baru</label>
                                <input type="password" name="new_password" required minlength="6">
                                <small style="color:var(--text-light);font-size:13px">Minimal 6 karakter</small>
                            </div>
                            <div class="form-group">
                                <label>Konfirmasi Password Baru</label>
                                <input type="password" name="confirm_password" required minlength="6">
                            </div>
                            <button type="submit" class="btn-primary">
                                <i class="fas fa-key"></i> Ubah Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
