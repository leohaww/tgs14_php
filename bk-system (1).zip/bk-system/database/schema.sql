-- Database Schema untuk Sistem Bimbingan Konseling

CREATE DATABASE IF NOT EXISTS bk_system;
USE bk_system;

-- Tabel Users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    avatar VARCHAR(255) DEFAULT 'default-avatar.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel Siswa
CREATE TABLE IF NOT EXISTS siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(20) UNIQUE NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('L', 'P') NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    tahun_ajaran VARCHAR(20) NOT NULL,
    tanggal_lahir DATE,
    alamat TEXT,
    no_telp VARCHAR(20),
    email VARCHAR(100),
    nama_wali VARCHAR(100),
    no_telp_wali VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel Konseling
CREATE TABLE IF NOT EXISTS konseling (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    konselor_id INT NOT NULL,
    tanggal_konseling DATETIME NOT NULL,
    jenis_konseling ENUM('Individual', 'Kelompok', 'Klasikal') DEFAULT 'Individual',
    kategori VARCHAR(50) NOT NULL,
    permasalahan TEXT NOT NULL,
    solusi TEXT,
    tindak_lanjut TEXT,
    status ENUM('Terjadwal', 'Selesai', 'Dibatalkan') DEFAULT 'Terjadwal',
    catatan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (konselor_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabel Pelanggaran
CREATE TABLE IF NOT EXISTS pelanggaran (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    tanggal_pelanggaran DATE NOT NULL,
    jenis_pelanggaran VARCHAR(100) NOT NULL,
    tingkat_pelanggaran ENUM('Ringan', 'Sedang', 'Berat') DEFAULT 'Ringan',
    deskripsi TEXT NOT NULL,
    sanksi TEXT,
    poin INT DEFAULT 0,
    status ENUM('Pending', 'Proses', 'Selesai') DEFAULT 'Pending',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabel Prestasi
CREATE TABLE IF NOT EXISTS prestasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    tanggal_prestasi DATE NOT NULL,
    jenis_prestasi VARCHAR(100) NOT NULL,
    tingkat ENUM('Sekolah', 'Kecamatan', 'Kabupaten', 'Provinsi', 'Nasional', 'Internasional') DEFAULT 'Sekolah',
    peringkat VARCHAR(50),
    penyelenggara VARCHAR(100),
    deskripsi TEXT,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabel Kunjungan
CREATE TABLE IF NOT EXISTS kunjungan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    tanggal_kunjungan DATETIME NOT NULL,
    tujuan_kunjungan TEXT NOT NULL,
    hasil_kunjungan TEXT,
    petugas_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    FOREIGN KEY (petugas_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert Default Admin User
INSERT INTO users (username, password, full_name, email, role) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@bksystem.com', 'admin'),
('konselor', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Guru BK', 'konselor@bksystem.com', 'user');

-- Password default untuk kedua user adalah: password
