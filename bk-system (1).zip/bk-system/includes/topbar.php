<div class="top-bar">
    <div class="page-title">
        <h1><?php echo isset($page_title) ? $page_title : 'Dashboard'; ?></h1>
        <p><?php echo isset($page_subtitle) ? $page_subtitle : 'Selamat datang di Sistem Bimbingan Konseling'; ?></p>
    </div>
    <a href="logout.php" class="logout-btn">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</div>
