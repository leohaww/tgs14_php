<aside class="sidebar">
    <div class="sidebar-header">
        <h2>Sistem BK</h2>
        <p>Enterprise Edition</p>
    </div>

    <div class="user-profile">
        <div class="user-avatar">
            <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
        </div>
        <div class="user-info">
            <h3><?php echo $_SESSION['full_name']; ?></h3>
            <p><?php echo $_SESSION['role']; ?></p>
        </div>
    </div>

    <nav class="nav-menu">
        <div class="nav-item">
            <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-th-large"></i>
                <span>Dashboard</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="siswa.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'siswa.php' ? 'active' : ''; ?>">
                <i class="fas fa-user-graduate"></i>
                <span>Data Siswa</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="konseling.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'konseling.php' ? 'active' : ''; ?>">
                <i class="fas fa-comments"></i>
                <span>Konseling</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="pelanggaran.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'pelanggaran.php' ? 'active' : ''; ?>">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Pelanggaran</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="prestasi.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'prestasi.php' ? 'active' : ''; ?>">
                <i class="fas fa-trophy"></i>
                <span>Prestasi</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="kunjungan.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'kunjungan.php' ? 'active' : ''; ?>">
                <i class="fas fa-clipboard-check"></i>
                <span>Kunjungan</span>
            </a>
        </div>
        <?php if($_SESSION['role'] == 'admin'): ?>
        <div class="nav-item">
            <a href="users.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                <i class="fas fa-users-cog"></i>
                <span>Manajemen User</span>
            </a>
        </div>
        <?php endif; ?>
        <div class="nav-item">
            <a href="laporan.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-bar"></i>
                <span>Laporan</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                <i class="fas fa-user-circle"></i>
                <span>Profil Saya</span>
            </a>
        </div>
        <div class="nav-item">
            <a href="bantuan.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'bantuan.php' ? 'active' : ''; ?>">
                <i class="fas fa-question-circle"></i>
                <span>Bantuan</span>
            </a>
        </div>
    </nav>
</aside>
